<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php'; // Your database connection file

$response = ['status' => 'error', 'message' => 'An unknown error occurred.'];

$input = json_decode(file_get_contents('php://input'), true);

$officer_id = $input['officer_id'] ?? '';

if (empty($officer_id)) {
    $response['message'] = 'Extension Officer ID is required for deletion.';
    echo json_encode($response);
    exit();
}

try {
    $stmt = $conn->prepare("DELETE FROM extension_officers WHERE officer_id = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error: " . $conn->error);
    }
    $stmt->bind_param("s", $officer_id);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            $response = ['status' => 'success', 'message' => 'Extension Officer deleted successfully!'];
        } else {
            $response['message'] = 'No Extension Officer found with the provided ID.';
        }
    } else {
        throw new Exception("Failed to delete extension officer: " . $stmt->error);
    }

    $stmt->close();

} catch (Exception $e) {
    error_log("Delete Extension Officer error: " . $e->getMessage());
    $response['message'] = 'An internal server error occurred: ' . $e->getMessage();
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>