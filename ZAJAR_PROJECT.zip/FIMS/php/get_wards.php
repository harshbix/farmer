<?php
include 'db.php';

header('Content-Type: application/json');

$districtId = isset($_GET['district_id']) ? intval($_GET['district_id']) : 0;

$wards = [];
if ($districtId > 0) {
    $stmt = $conn->prepare("SELECT id, name FROM wards WHERE district_id = ? ORDER BY name ASC");
    $stmt->bind_param("i", $districtId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $wards[] = $row;
        }
    }
    $stmt->close();
}
echo json_encode($wards);

$conn->close();
?>