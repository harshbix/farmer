<?php
include 'db.php';

header('Content-Type: application/json');

$wardId = isset($_GET['ward_id']) ? intval($_GET['ward_id']) : 0;

$villages = [];
if ($wardId > 0) {
    $stmt = $conn->prepare("SELECT id, name FROM villages WHERE ward_id = ? ORDER BY name ASC");
    $stmt->bind_param("i", $wardId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $villages[] = $row;
        }
    }
    $stmt->close();
}
echo json_encode($villages);

$conn->close();
?>