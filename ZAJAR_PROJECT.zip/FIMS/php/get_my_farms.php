<?php
session_start();
require 'db.php'; // Ensure this path is correct for your database connection file

header('Content-Type: application/json');

// Check if the farmer is logged in
if (!isset($_SESSION['farmer_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in.']);
    exit;
}

$loggedInFarmerId = $_SESSION['farmer_id'];

try {
    // Prepare a statement to fetch farms belonging to the logged-in farmer
    // IMPORTANT: Ensure 'crop_type' column exists in your 'farms' table.
    $stmt = $conn->prepare("SELECT farm_id, farm_name, size_acres, crop_type, village, ward, district, status FROM farms WHERE farmer_id = ? ORDER BY farm_id DESC");
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    $stmt->bind_param("s", $loggedInFarmerId); // 's' for string, assuming farmer_id is a string or can be treated as such
    $stmt->execute();
    $result = $stmt->get_result();

    $farms = [];
    while ($row = $result->fetch_assoc()) {
        $farms[] = $row;
    }
    $stmt->close();

    // Return success response with the fetched farms
    echo json_encode(['status' => 'success', 'farms' => $farms]);

} catch (Exception $e) {
    error_log("Error fetching farmer's farms: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Failed to retrieve farms.']);
} finally {
    // Close the database connection
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
}
?>