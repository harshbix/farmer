<?php
session_start();
require 'db.php'; // Your database connection file

header('Content-Type: application/json');

$response = ['status' => 'error', 'message' => 'Unauthorized access.'];

// Ensure only logged-in Extension Officers can access this
if (!isset($_SESSION['officer_id']) || !$_SESSION['logged_in']) {
    // Optionally, add a redirect flag for client-side handling
    $response['redirect'] = 'login.html';
    echo json_encode($response);
    exit;
}

$officerWard = null; // Initialize officerWard

// Fetch the officer's ward from their profile (if available in session or directly from DB)
// For simplicity, we'll assume it's passed as a GET parameter for now,
// but ideally, you'd get it from the officer's session or re-fetch their profile here.
// However, since eo_farmers.js is already fetching officer profile, we'll rely on that.
// For this PHP script, we'll expect the ward to be passed as a GET parameter from the JS.
if (isset($_GET['ward'])) {
    $officerWard = urldecode($_GET['ward']);
} else {
    // If ward is not provided, it's an error for this specific requirement
    $response['message'] = 'Officer ward not provided for filtering farmers.';
    echo json_encode($response);
    exit;
}

try {
    // Prepare statement to fetch farmers for the specific ward
    // Adjust table and column names to match your database schema
    $stmt = $conn->prepare("SELECT farmer_id, first_name, middle_name, last_name, phone, email, village, ward, district FROM farmers WHERE ward = ?");

    if (!$stmt) {
        throw new Exception("Database prepare error: " . $conn->error);
    }

    $stmt->bind_param("s", $officerWard);
    $stmt->execute();
    $result = $stmt->get_result();

    $farmers = [];
    while ($row = $result->fetch_assoc()) {
        $farmers[] = $row;
    }

    $response = ['status' => 'success', 'farmers' => $farmers];
    $stmt->close();

} catch (Exception $e) {
    error_log("Get All Farmers error: " . $e->getMessage());
    $response['message'] = 'An internal server error occurred while fetching farmers.';
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
echo json_encode($response);
?>