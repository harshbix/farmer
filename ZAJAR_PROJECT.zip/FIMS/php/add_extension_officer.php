<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$response = ['status' => 'error', 'message' => 'An unknown error occurred.'];

// Check if district officer is logged in
if (!isset($_SESSION['officer_id'])) {
    $response['message'] = 'Unauthorized access.';
    $response['redirect'] = '../district_login.html';
    echo json_encode($response);
    exit();
}

$officer_id = $_SESSION['officer_id'];

$input = json_decode(file_get_contents('php://input'), true);

$full_name = $input['full_name'] ?? '';
$email = $input['email'] ?? '';
$ward = $input['ward'] ?? '';
$phone = $input['phone'] ?? '';
$password = $input['password'] ?? '';

if (empty($full_name) || empty($email) || empty($ward) || empty($phone)) {
    $response['message'] = 'All fields are required (Full Name, Email, Ward and Phone).';
    echo json_encode($response);
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $response['message'] = 'Invalid email format.';
    echo json_encode($response);
    exit();
}

try {
    // Get the district of the logged-in district officer
    $stmt = $conn->prepare("SELECT district FROM district_officers WHERE officer_id = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error (get district): " . $conn->error);
    }
    $stmt->bind_param("s", $officer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $response['message'] = 'District officer not found.';
        echo json_encode($response);
        exit();
    }
    
    $officer_data = $result->fetch_assoc();
    $district_name = $officer_data['district'];
    $stmt->close();
    
    // Get the district ID from the districts table
    $stmt = $conn->prepare("SELECT id FROM districts WHERE name = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error (get district ID): " . $conn->error);
    }
    
    $stmt->bind_param("s", $district_name);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $response['message'] = 'District not found in districts table: ' . $district_name;
        echo json_encode($response);
        exit();
    }
    
    $district_data = $result->fetch_assoc();
    $district_id = $district_data['id'];
    $stmt->close();
    
    // Check if extension officer email already exists
    $stmt = $conn->prepare("SELECT officer_id FROM extension_officers WHERE email = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error (check email): " . $conn->error);
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $response['message'] = 'An officer with this email already exists.';
        echo json_encode($response);
        exit();
    }
    $stmt->close();

    // Verify that the selected ward belongs to the district using district_id
    $stmt = $conn->prepare("SELECT name FROM wards WHERE district_id = ? AND name = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error (verify ward): " . $conn->error);
    }
    $stmt->bind_param("is", $district_id, $ward);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows === 0) {
        $response['message'] = 'Selected ward does not belong to your district.';
        echo json_encode($response);
        exit();
    }
    $stmt->close();

    // Generate unique Extension Officer ID (e.g. OFC-45821-792)
    $timestamp = time();
    $rand      = rand(100, 999);
    $extension_officer_id  = "OFC-" . substr($timestamp, -5) . "-" . $rand;

    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert extension officer with district information
    $stmt = $conn->prepare("INSERT INTO extension_officers (officer_id, full_name, email, ward, phone_number, password_hash, district) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        throw new Exception("Database prepare error (insert): " . $conn->error);
    }
    $stmt->bind_param("sssssss", $extension_officer_id, $full_name, $email, $ward, $phone, $hashed_password, $district_name);

    if ($stmt->execute()) {
        $response = [
            'status' => 'success', 
            'message' => 'Extension Officer added successfully!', 
            'officer_id' => $extension_officer_id,
            'district' => $district_name
        ];
    } else {
        throw new Exception("Failed to add extension officer: " . $stmt->error);
    }

    $stmt->close();

} catch (Exception $e) {
    error_log("Add Extension Officer error: " . $e->getMessage());
    $response['message'] = 'An internal server error occurred: ' . $e->getMessage();
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>