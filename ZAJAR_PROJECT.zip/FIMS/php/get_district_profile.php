<?php
session_start();
header('Content-Type: application/json');

require_once 'db.php';

$response = ['status' => 'error', 'message' => 'Unauthorized'];

if (!isset($_SESSION['officer_id'])) {
    $response['redirect'] = 'district_login.php';
    echo json_encode($response);
    exit();
}

$officer_id = $_SESSION['officer_id']; // Use $_SESSION['officer_id']

try {
    $stmt = $conn->prepare("SELECT officer_id, full_name, email, phone_number, district FROM district_officers WHERE officer_id = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error: " . $conn->error);
    }

    $stmt->bind_param("s", $officer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $officer = $result->fetch_assoc();
        $response = ['status' => 'success', 'officer' => $officer];
    } else {
        $response['message'] = 'District Officer profile not found.';
    }

    $stmt->close();

} catch (Exception $e) {
    error_log("Get District Officer Profile error: " . $e->getMessage());
    $response['message'] = 'An internal server error occurred while fetching profile.';
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
echo json_encode($response);
?>