<?php
header('Content-Type: text/plain'); // Set header to plain text for simplicity
echo "Hello from test_output.php!";
?>