<?php
session_start();
header('Content-Type: application/json');

require_once 'db.php'; // Include your database connection

$response = ['status' => 'error', 'message' => 'Unauthorized'];

// Ensure only logged-in Extension Officers can access this
if (!isset($_SESSION['officer_id'])) {
    $response['redirect'] = '../eo_login.html'; // Redirect to login if not authenticated
    echo json_encode($response);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $officer_id = $_SESSION['officer_id'];
    $farmer_id = $_POST['farmer_id'] ?? null;

    if (!$farmer_id) {
        $response['message'] = 'Farmer ID is missing.';
        echo json_encode($response);
        exit();
    }

    try {
        // Proceed with deletion if authorized
        $stmt = $conn->prepare("DELETE FROM farmers WHERE farmer_id = ?");
        if (!$stmt) {
            throw new Exception("Failed to prepare delete statement: " . $conn->error);
        }

        $stmt->bind_param("s", $farmer_id);

        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $response = ['status' => 'success', 'message' => 'Farmer deleted successfully!'];
            } else {
                $response = ['status' => 'error', 'message' => 'Farmer not found or already deleted.'];
            }
        } else {
            throw new Exception("Failed to delete farmer: " . $stmt->error);
        }
        $stmt->close();

    } catch (Exception $e) {
        error_log("Error deleting farmer: " . $e->getMessage());
        $response = ['status' => 'error', 'message' => 'An internal server error occurred. Please try again later.'];
    } finally {
        if (isset($conn) && $conn) {
            $conn->close();
        }
    }
}

echo json_encode($response);
?>