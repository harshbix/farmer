<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$response = ['status' => 'error', 'message' => 'An unknown error occurred.'];

// Check if district officer is logged in
if (!isset($_SESSION['officer_id'])) {
    $response['message'] = 'Unauthorized access.';
    $response['redirect'] = '../district_login.html';
    echo json_encode($response);
    exit();
}

$officer_id = $_SESSION['officer_id'];

try {
    // First, get the district of the logged-in officer
    $stmt = $conn->prepare("SELECT district FROM district_officers WHERE officer_id = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error (get district): " . $conn->error);
    }
    
    $stmt->bind_param("s", $officer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $response['message'] = 'District officer not found. Officer ID: ' . $officer_id;
        echo json_encode($response);
        exit();
    }
    
    $officer_data = $result->fetch_assoc();
    $district_name = $officer_data['district'];
    $stmt->close();
    
    // Get the district ID from the districts table
    $stmt = $conn->prepare("SELECT id FROM districts WHERE name = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error (get district ID): " . $conn->error);
    }
    
    $stmt->bind_param("s", $district_name);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $response['message'] = 'District not found in districts table: ' . $district_name;
        echo json_encode($response);
        exit();
    }
    
    $district_data = $result->fetch_assoc();
    $district_id = $district_data['id'];
    $stmt->close();
    
    // Now get all wards in that district using district_id
    $stmt = $conn->prepare("SELECT DISTINCT name FROM wards WHERE district_id = ? ORDER BY name ASC");
    if (!$stmt) {
        throw new Exception("Database prepare error (get wards): " . $conn->error);
    }
    $stmt->bind_param("i", $district_id);
    $stmt->execute();
    $result = $wards_result = $stmt->get_result();
    
    $wards = [];
    while ($row = $result->fetch_assoc()) {
        $wards[] = $row['name'];
    }
    
    $stmt->close();
    
    $response = [
        'status' => 'success',
        'wards' => $wards,
        'district' => $district_name,
        'district_id' => $district_id
    ];
    
} catch (Exception $e) {
    error_log("Get District Wards error: " . $e->getMessage());
    $response['message'] = 'An internal server error occurred: ' . $e->getMessage();
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>