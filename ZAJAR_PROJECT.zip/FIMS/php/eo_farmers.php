<?php
session_start();

// Check if the officer is NOT logged in or session is invalid
if (!isset($_SESSION['officer_id'])) {
    header("Location: login.html");
    exit();
}

include('../eo_farmers.html');
?>