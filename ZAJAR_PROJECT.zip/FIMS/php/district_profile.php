<?php
session_start();
header('Content-Type: application/json');

require_once 'db.php'; // Assuming db.php contains your database connection logic

$response = ['status' => 'error', 'message' => 'Unauthorized'];

// Check if the officer is logged in
if (!isset($_SESSION['officer_id'])) {
    $response['redirect'] = 'district_login.php'; // Redirect to login page if not logged in
    echo json_encode($response);
    exit();
}

$officer_id = $_SESSION['officer_id']; // Get the logged-in officer's ID from the session

try {
    // Prepare the SQL statement to select officer details
    $stmt = $conn->prepare("SELECT officer_id, full_name, email, phone_number, district FROM district_officers WHERE officer_id = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error: " . $conn->error);
    }

    $stmt->bind_param("s", $officer_id); // Bind the officer_id parameter
    $stmt->execute(); // Execute the statement
    $result = $stmt->get_result(); // Get the result set

    if ($result->num_rows === 1) {
        $officer = $result->fetch_assoc(); // Fetch the officer's data
        $response = ['status' => 'success', 'officer' => $officer];
    } else {
        $response['message'] = 'District Officer profile not found.';
    }

    $stmt->close(); // Close the statement

} catch (Exception $e) {
    error_log("Get District Officer Profile error: " . $e->getMessage()); // Log the error for debugging
    $response['message'] = 'An internal server error occurred: ' . $e->getMessage();
} finally {
    if (isset($conn) && $conn) {
        $conn->close(); // Close the database connection
    }
}

echo json_encode($response); // Output the JSON response
?>