<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php'; // Make sure this path is correct for your database connection file

$response = ['status' => 'error', 'message' => 'An unknown error occurred.'];

// Check if the officer is logged in
if (!isset($_SESSION['officer_id'])) {
    $response['message'] = 'Unauthorized. Please log in.';
    echo json_encode($response);
    exit();
}

$officer_id = $_SESSION['officer_id'];

// Get raw POST data
$input = json_decode(file_get_contents('php://input'), true);

$current_password = $input['current_password'] ?? '';
$new_password = $input['new_password'] ?? '';
$confirm_password = $input['confirm_password'] ?? '';

// Input validation
if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
    $response['message'] = 'All password fields are required.';
    echo json_encode($response);
    exit();
}

if ($new_password !== $confirm_password) {
    $response['message'] = 'New password and confirm password do not match.';
    echo json_encode($response);
    exit();
}

// Basic password strength check (optional, but recommended)
// You might want to make this more robust
if (strlen($new_password) < 8) {
    $response['message'] = 'New password must be at least 8 characters long.';
    echo json_encode($response);
    exit();
}

try {
    // 1. Verify current password
    $stmt = $conn->prepare("SELECT password_hash FROM district_officers WHERE officer_id = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error (current password): " . $conn->error);
    }
    $stmt->bind_param("s", $officer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        $response['message'] = 'Officer not found.'; // This should ideally not happen if session is valid
        echo json_encode($response);
        exit();
    }

    $officer = $result->fetch_assoc();
    $hashed_current_password = $officer['password_hash'];

    // Use password_verify to check the submitted current password against the hashed password in the DB
    if (!password_verify($current_password, $hashed_current_password)) {
        $response['message'] = 'Incorrect current password.';
        echo json_encode($response);
        exit();
    }

    $stmt->close();

    // 2. Hash the new password before storing it
    $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);

    // 3. Update the password in the database
    $stmt = $conn->prepare("UPDATE district_officers SET password_hash = ? WHERE officer_id = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error (update password): " . $conn->error);
    }
    $stmt->bind_param("ss", $hashed_new_password, $officer_id);

    if ($stmt->execute()) {
        $response = ['status' => 'success', 'message' => 'Password updated successfully!'];
    } else {
        throw new Exception("Failed to update password: " . $stmt->error);
    }

    $stmt->close();

} catch (Exception $e) {
    error_log("Change Password error: " . $e->getMessage()); // Log the error for server-side debugging
    $response['message'] = 'An internal server error occurred: ' . $e->getMessage();
} finally {
    // Ensure database connection is closed
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>