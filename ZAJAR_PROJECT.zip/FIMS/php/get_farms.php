<?php
session_start();
include 'db.php'; // Ensure this path is correct and db.php connects to your database

header('Content-Type: application/json');

$farmerId = $_SESSION['farmer_id'];

$farms = [];
if (!empty($farmerId)) {
    try {
        $stmt = $conn->prepare("SELECT farm_id, farm_name FROM farms WHERE farmer_id = ? AND status = 'Verified' ORDER BY farm_name ASC");
        if (!$stmt) {
            throw new Exception("Failed to prepare statement: " . $conn->error);
        }
        $stmt->bind_param("s", $farmerId);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                $farms[] = $row;
            }
            // Set the response for success with farms data
            $response = ['status' => 'success', 'farms' => $farms];
        } else {
            // If no farms found, it's still a successful query, just with an empty list
            $response = ['status' => 'success', 'farms' => [], 'message' => 'No verified farms found for your account.'];
        }
        $stmt->close();

    } catch (Exception $e) {
        // Catch any database or preparation errors
        error_log("Error fetching farms: " . $e->getMessage());
        $response = ['status' => 'error', 'message' => 'Failed to fetch farms. (Detail: ' . $e->getMessage() . ')'];
    }
} else {
    // This else block handles cases where farmerId from session is unexpectedly empty
    $response = ['status' => 'error', 'message' => 'Farmer ID not found in session. Please log in again.'];
}

echo json_encode($response); // Encode and send the final response

// Ensure the connection is closed
if (isset($conn) && $conn instanceof mysqli) {
    $conn->close();
}
?>