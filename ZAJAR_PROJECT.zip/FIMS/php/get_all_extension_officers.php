<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$response = ['status' => 'error', 'message' => 'An unknown error occurred.'];

// Check if district officer is logged in
if (!isset($_SESSION['officer_id'])) {
    $response['message'] = 'Unauthorized access.';
    $response['redirect'] = '../district_login.html';
    echo json_encode($response);
    exit();
}

$officer_id = $_SESSION['officer_id'];

try {
    // First, get the district of the logged-in officer
    $stmt = $conn->prepare("SELECT district FROM district_officers WHERE officer_id = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error (get district): " . $conn->error);
    }
    $stmt->bind_param("s", $officer_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $response['message'] = 'District officer not found.';
        echo json_encode($response);
        exit();
    }
    
    $officer_data = $result->fetch_assoc();
    $district = $officer_data['district'];
    $stmt->close();
    
    // Now get all extension officers in the same district
    $stmt = $conn->prepare("SELECT officer_id, full_name, email, ward, district FROM extension_officers WHERE district = ? ORDER BY full_name ASC");
    if (!$stmt) {
        throw new Exception("Database prepare error (get officers): " . $conn->error);
    }
    $stmt->bind_param("s", $district);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $officers = [];
    while ($row = $result->fetch_assoc()) {
        $officers[] = $row;
    }
    
    $stmt->close();
    
    $response = [
        'status' => 'success',
        'officers' => $officers,
        'district' => $district
    ];
    
} catch (Exception $e) {
    error_log("Get All Extension Officers error: " . $e->getMessage());
    $response['message'] = 'An internal server error occurred: ' . $e->getMessage();
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>