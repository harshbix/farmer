<?php
session_start();
header('Content-Type: application/json');

require_once 'db.php';

$response = ['status' => 'error', 'message' => 'Unauthorized'];

if (!isset($_SESSION['officer_id'])) {
    $response['redirect'] = '../eo_login.html';
    echo json_encode($response);
    exit();
}

// Get ward from GET request
$ward = isset($_GET['ward']) ? trim($_GET['ward']) : '';

try {
    if (empty($ward)) {
        // Fallback or error if ward is not provided
        throw new Exception("Ward parameter is missing.");
    }

    // Count verified farms for the specific ward
    // Assuming 'farms' table has a 'ward' column
    $stmt = $conn->prepare("SELECT COUNT(farm_id) AS total_farms FROM farms WHERE status = 'Verified' AND ward = ?");
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    $stmt->bind_param("s", $ward); // Bind ward parameter

    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $count = $row['total_farms'];
    $stmt->close();

    $response = ['status' => 'success', 'count' => $count];

} catch (Exception $e) {
    error_log("Error fetching verified farm count: " . $e->getMessage());
    $response = ['status' => 'error', 'message' => 'Failed to retrieve verified farm count: ' . $e->getMessage()];
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
echo json_encode($response);
?>