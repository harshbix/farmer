<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$response = ['status' => 'error', 'message' => 'Invalid request.'];

if (!isset($_SESSION['officer_id'])) {
    $response['message'] = 'Unauthorized: Please log in.';
    http_response_code(401);
    echo json_encode($response);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$id = $input['id'] ?? '';

// Basic validation
if (empty($id) || !is_numeric($id)) {
    $response['message'] = 'Price ID is required for deletion.';
    echo json_encode($response);
    exit();
}

try {
    $stmt = $conn->prepare("DELETE FROM market_prices WHERE id = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error: " . $conn->error);
    }

    $stmt->bind_param("i", $id); // 'i' for integer

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            $response = ['status' => 'success', 'message' => 'Market price deleted successfully.'];
        } else {
            $response = ['status' => 'info', 'message' => 'Record not found for deletion.'];
        }
    } else {
        throw new Exception("Execute failed: " . $stmt->error);
    }

    $stmt->close();

} catch (Exception $e) {
    error_log("Delete Market Price error: " . $e->getMessage());
    $response['message'] = 'An internal server error occurred: ' . $e->getMessage();
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
echo json_encode($response);
?>