<?php
session_start();
header('Content-Type: application/json');

require 'db.php'; // Ensure this path is correct

$response = ['status' => 'error', 'message' => 'Unauthorized'];

if (!isset($_SESSION['farmer_id'])) {
    // If not logged in, redirect to login page
    $response['redirect'] = '../login.html'; // Assuming login.html is one level up
    echo json_encode($response);
    exit();
}

$farmerId = $_SESSION['farmer_id'];
$farmId = trim($_POST['farm_name'] ?? ''); // This will now be farm_id from the dropdown value
$cropName = trim($_POST['crop_name'] ?? '');
$quantity = trim($_POST['quantity'] ?? '0');
$harvestDate = trim($_POST['harvest_date'] ?? ''); // FIXED: Changed from 'recorded_at' to 'harvest_date'

// Basic validation for required fields
if (empty($farmId) || !is_numeric($quantity) || $quantity <= 0 || empty($cropName) || empty($harvestDate)) {
    echo json_encode(['status' => 'error', 'message' => 'Please fill all required fields correctly (quantity must be a positive number, and harvest date is required).']);
    exit();
}

try {
    // Validate that the selected farm_id belongs to the logged-in farmer and is verified
    $stmtFarm = $conn->prepare("SELECT farm_id FROM farms WHERE farmer_id = ? AND farm_id = ? AND status = 'Verified'");
    if (!$stmtFarm) {
        throw new Exception("Failed to prepare farm validation statement: " . $conn->error);
    }
    $stmtFarm->bind_param("si", $farmerId, $farmId);
    $stmtFarm->execute();
    $resultFarm = $stmtFarm->get_result();

    if ($resultFarm->num_rows != 1) {
        throw new Exception("Selected farm is not valid for your account or is not verified.");
    }
    $stmtFarm->close();

    // 2. Insert new output record
    // FIXED: Corrected the INSERT statement to match the number of parameters
    $stmt = $conn->prepare("INSERT INTO outputs (farm_id, farmer_id, crop_name, quantity, recorded_at) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) {
        throw new Exception("Failed to prepare output insertion statement: " . $conn->error);
    }

    // FIXED: Added the missing parameter and corrected the binding
    $stmt->bind_param("issds", $farmId, $farmerId, $cropName, $quantity, $harvestDate);

    if ($stmt->execute()) {
        $newOutputId = $conn->insert_id; // Get the ID of the newly inserted row

        $stmtFetchOutput = $conn->prepare("SELECT output_id, farm_id, crop_name, quantity, recorded_at FROM outputs WHERE output_id = ?");
        if (!$stmtFetchOutput) {
            throw new Exception("Failed to prepare new output fetch statement: " . $conn->error);
        }
        $stmtFetchOutput->bind_param("i", $newOutputId);
        $stmtFetchOutput->execute();
        $resultOutput = $stmtFetchOutput->get_result();
        $newOutputData = $resultOutput->fetch_assoc();
        $stmtFetchOutput->close();

        // Respond with success and new Farm Output Data
        echo json_encode(['status' => 'success', 'message' => 'New farm output registered successfully', 'output' => $newOutputData]);

    } else {
        throw new Exception("Failed to register output: " . $stmt->error);
    }

    $stmt->close(); // Close the insert statement

} catch (Exception $e) {
    error_log("Error registering output: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Failed to register output. Please try again. (Detail: ' . $e->getMessage() . ')']);
} finally {
    // Ensure the connection is closed
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
}
?>