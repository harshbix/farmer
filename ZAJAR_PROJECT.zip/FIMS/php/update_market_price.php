<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$response = ['status' => 'error', 'message' => 'Invalid request.'];

if (!isset($_SESSION['officer_id'])) {
    $response['message'] = 'Unauthorized: Please log in.';
    http_response_code(401);
    echo json_encode($response);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

$id = $input['id'] ?? '';
$crop_name = $input['crop_name'] ?? '';
$unit = $input['unit'] ?? '';
$price_tsh = $input['price_tsh'] ?? '';
$market_name = $input['market_name'] ?? '';

// Basic validation
if (empty($id) || !is_numeric($id) || empty($crop_name) || empty($unit) || !is_numeric($price_tsh) || empty($market_name)) {
    $response['message'] = 'All fields are required and price must be a number, and ID must be valid.';
    echo json_encode($response);
    exit();
}

try {
    $stmt = $conn->prepare("UPDATE market_prices SET crop_name = ?, unit = ?, price_tsh = ?, market_name = ? WHERE id = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error: " . $conn->error);
    }

    $stmt->bind_param("ssdsi", $crop_name, $unit, $price_tsh, $market_name, $id); // 'ssdsi' for string, string, double, string, integer

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            $response = ['status' => 'success', 'message' => 'Market price updated successfully.'];
        } else {
            $response = ['status' => 'info', 'message' => 'No changes made or record not found.'];
        }
    } else {
        throw new Exception("Execute failed: " . $stmt->error);
    }

    $stmt->close();

} catch (Exception $e) {
    error_log("Update Market Price error: " . $e->getMessage());
    $response['message'] = 'An internal server error occurred: ' . $e->getMessage();
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
echo json_encode($response);
?>