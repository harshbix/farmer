<?php
session_start();
include 'db.php';

header('Content-Type: application/json');

$response = ['status' => 'error', 'message' => 'Unauthorized'];

if (!isset($_SESSION['farmer_id'])) {
    $response['redirect'] = '../login.html';
    echo json_encode($response);
    exit();
}

$farmId = $_GET['farm_id'] ?? '';

if (empty($farmId)) {
    $response['message'] = "Farm ID is required.";
    echo json_encode($response);
    exit();
}

$crops = [];
try {
    // Assuming crop names are stored in the 'outputs' table associated with farm_id
    // Adjust this query based on your actual database schema for crops
    $stmt = $conn->prepare("SELECT DISTINCT crop_type FROM farms WHERE farm_id = ? ORDER BY crop_type ASC");
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    $stmt->bind_param("i", $farmId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $crops[] = $row;
        }
    }
    $stmt->close();
    $response = ['status' => 'success', 'crops' => $crops];

} catch (Exception $e) {
    error_log("Error fetching crops: " . $e->getMessage());
    $response['message'] = "Failed to fetch crops. (Detail: " . $e->getMessage() . ")";
} finally {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
}
echo json_encode($response);
?>