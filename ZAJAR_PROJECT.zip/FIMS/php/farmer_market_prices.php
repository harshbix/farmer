<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php'; // Your database connection file

$response = ['status' => 'error', 'message' => 'Unauthorized'];

// Optional: Check if farmer is logged in if this data requires authentication
if (!isset($_SESSION['farmer_id'])) {
    $response['message'] = 'Authentication required.';
    echo json_encode($response);
    exit();
}

try {
    $stmt = $conn->prepare("SELECT id, crop_name, unit, price_tsh, market_name, updated_at FROM market_prices ORDER BY created_at DESC");
    if (!$stmt) {
        throw new Exception("Database prepare error: " . $conn->error);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    $prices = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $prices[] = $row;
        }
    }
    $response = ['status' => 'success', 'prices' => $prices];

    $stmt->close();

} catch (Exception $e) {
    error_log("Get Market Prices error: " . $e->getMessage());
    $response['message'] = 'An internal server error occurred while fetching market prices.';
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
echo json_encode($response);
?>