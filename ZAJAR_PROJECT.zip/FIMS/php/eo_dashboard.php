<?php
session_start();

// Set headers to prevent caching for security (important for back button)
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // A date in the past

// Strict session check: If officer_id is NOT set in session, redirect to login.
if (!isset($_SESSION['officer_id'])) {
    header("Location: ../eo_login.html");
    exit();
}

// If the user IS logged in, then include the HTML content.
// This ensures that the HTML is only ever served if the session is active.
include '../eo_dashboard.html';
?>