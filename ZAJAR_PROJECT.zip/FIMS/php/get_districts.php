<?php
include 'db.php';

header('Content-Type: application/json');

$sql = "SELECT id, name FROM districts ORDER BY name ASC";
$result = $conn->query($sql);

$districts = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $districts[] = $row;
    }
}
echo json_encode($districts);

$conn->close();
?>