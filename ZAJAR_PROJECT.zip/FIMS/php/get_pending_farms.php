<?php
session_start();
require 'db.php'; // Adjust path as necessary, relative to this script

header('Content-Type: application/json');

// Ensure only logged-in Extension Officers can access this
if (!isset($_SESSION['officer_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.', 'redirect' => '../eo_login.html']);
    exit;
}

// Get ward from GET request
$ward = isset($_GET['ward']) ? trim($_GET['ward']) : '';

try {
    if (empty($ward)) {
        throw new Exception("Ward parameter is missing.");
    }

    // Select farms with 'Pending' status for the specific ward
    $stmt = $conn->prepare("SELECT farm_id, farmer_id, farm_name, size_acres, village, ward, district, date_registered, status FROM farms WHERE status = 'Pending' AND ward = ? ORDER BY date_registered ASC");
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    $stmt->bind_param("s", $ward); // Bind the ward parameter
    $stmt->execute();
    $result = $stmt->get_result();

    $pendingFarms = [];
    while ($row = $result->fetch_assoc()) {
        $pendingFarms[] = $row;
    }
    $stmt->close();

    echo json_encode(['status' => 'success', 'farms' => $pendingFarms]);

} catch (Exception $e) {
    error_log("Error fetching pending farms: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Failed to retrieve pending farms: ' . $e->getMessage()]);
} finally {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
}
?>