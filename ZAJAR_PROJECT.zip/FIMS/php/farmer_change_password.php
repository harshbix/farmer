<?php
session_start();
require 'db.php'; // Ensure your database connection file is correctly linked

header('Content-Type: application/json');

$response = ['status' => 'error', 'message' => 'Unauthorized access or invalid request.'];

// Ensure only logged-in farmers can access this
// We will rely primarily on farmer_id being set in the session
if (!isset($_SESSION['farmer_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in.']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $farmerId = $_SESSION['farmer_id'];
    // Use names consistent with HTML form: currentPassword, newPassword, confirmPassword
    $currentPassword = $_POST['currentPassword'] ?? '';
    $newPassword = $_POST['newPassword'] ?? '';
    $confirmPassword = $_POST['confirmPassword'] ?? '';

    if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
        $response['message'] = 'All password fields are required.';
        echo json_encode($response);
        exit;
    }

    if ($newPassword !== $confirmPassword) {
        $response['message'] = 'New password and confirm password do not match.';
        echo json_encode($response);
        exit;
    }

    // Basic server-side validation for new password length
    if (strlen($newPassword) < 6) { // Example: minimum 6 characters
        $response['message'] = 'New password must be at least 6 characters long.';
        echo json_encode($response);
        exit;
    }

    try {
        // 1. Fetch current hashed password from database using the 'password' column name
        $stmt = $conn->prepare("SELECT password_hash FROM farmers WHERE farmer_id = ?");
        if (!$stmt) {
            throw new Exception("Database prepare error for select: " . $conn->error);
        }
        $stmt->bind_param("s", $farmerId); // Assuming farmer_id is an integer
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $farmer = $result->fetch_assoc();
            $hashedPasswordFromDb = $farmer['password_hash']; // Assuming 'password' is the column name

            // 2. Verify the provided current password against the stored hash
            if (password_verify($currentPassword, $hashedPasswordFromDb)) {
                // Current password is correct, hash the new password
                $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);

                // 3. Update the password in the database
                // Make sure you update the correct column, using 'password' as assumed
                $updateStmt = $conn->prepare("UPDATE farmers SET password_hash = ? WHERE farmer_id = ?");
                if (!$updateStmt) {
                    throw new Exception("Database prepare error for update: " . $conn->error);
                }
                $updateStmt->bind_param("ss", $newPasswordHash, $farmerId); // Assuming password is string, farmer_id is integer

                if ($updateStmt->execute()) {
                    $response = ['status' => 'success', 'message' => 'Password updated successfully.'];
                } else {
                    throw new Exception("Failed to execute password update: " . $updateStmt->error);
                }
                $updateStmt->close();
            } else {
                // Current password does not match
                $response['message'] = 'Incorrect current password.';
            }
        } else {
            $response['message'] = 'Farmer not found.';
        }

        $stmt->close();

    } catch (Exception $e) {
        error_log("Change password error: " . $e->getMessage()); // Log the error for debugging
        $response['message'] = 'An internal server error occurred. Please try again later.';
    } finally {
        if (isset($conn) && $conn->ping()) {
            $conn->close();
        }
    }
}
echo json_encode($response);
?>