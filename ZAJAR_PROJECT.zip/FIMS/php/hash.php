<?php
echo password_hash("Password123", PASSWORD_DEFAULT);
?>