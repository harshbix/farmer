<?php
session_start();
require_once 'db.php';

header('Content-Type: application/json');

$response = ['status' => 'error', 'message' => 'Unauthorized'];

if (!isset($_SESSION['farmer_id'])) {
    $response['redirect'] = '../login.html';
    echo json_encode($response);
    exit();
}

$farmer_id = $_SESSION['farmer_id'];

try {
    // Select outputs, joining with farms and crops to get names
    $stmt = $conn->prepare("SELECT output_id, farm_id, crop_name, quantity, recorded_at FROM outputs WHERE farmer_id = ? ORDER BY recorded_at DESC");

    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }

    $stmt->bind_param("s", $farmer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $outputs = [];
    while ($row = $result->fetch_assoc()) {
        $outputs[] = $row;
    }
    $stmt->close();

    $response = ['status' => 'success', 'outputs' => $outputs];

} catch (Exception $e) {
    error_log("Error fetching farmer outputs: " . $e->getMessage());
    $response = ['status' => 'error', 'message' => 'Failed to retrieve outputs: ' . $e->getMessage()];
} finally {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
}

echo json_encode($response);
?>