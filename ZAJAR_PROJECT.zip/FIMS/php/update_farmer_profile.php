<?php
session_start();
require 'db.php'; // Ensure your database connection file is correctly linked

header('Content-Type: application/json');

// Check if the farmer is logged in
if (!isset($_SESSION['farmer_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in.']);
    exit;
}

$farmerId = $_SESSION['farmer_id'];

// Get data from the POST request
$firstName = trim($_POST['firstName'] ?? '');
$middleName = trim($_POST['middleName'] ?? '');
$lastName = trim($_POST['lastName'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');
$village = trim($_POST['village'] ?? '');
$ward = trim($_POST['ward'] ?? '');
$district = trim($_POST['district'] ?? '');

// Basic validation (you can add more comprehensive validation)
if (empty($firstName) || empty($lastName) || empty($phone) || empty($village) || empty($ward) || empty($district)) {
    echo json_encode(['status' => 'error', 'message' => 'Please fill all required fields: First Name, Last Name, Phone, Village, Ward, District.']);
    exit;
}

try {
    // Prepare the SQL UPDATE statement
    $stmt = $conn->prepare("UPDATE farmers SET 
                            first_name = ?, 
                            middle_name = ?, 
                            last_name = ?, 
                            phone = ?, 
                            email = ?, 
                            village = ?, 
                            ward = ?, 
                            district = ? 
                            WHERE farmer_id = ?");

    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }

    // Bind parameters
    // 'ssssssssi' corresponds to (string, string, string, string, string, string, string, string, integer)
    $stmt->bind_param("ssssssssi", 
                      $firstName, 
                      $middleName, 
                      $lastName, 
                      $phone, 
                      $email, 
                      $village, 
                      $ward, 
                      $district, 
                      $farmerId);

    // Execute the statement
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['status' => 'success', 'message' => 'Profile updated successfully!']);
        } else {
            // No rows affected might mean data was the same or farmer_id not found
            echo json_encode(['status' => 'info', 'message' => 'No changes detected or farmer ID not found.']);
        }
    } else {
        throw new Exception("Failed to execute statement: " . $stmt->error);
    }

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    error_log("Error updating farmer profile: " . $e->getMessage()); // Log the error for debugging
    echo json_encode(['status' => 'error', 'message' => 'An error occurred while updating your profile. Please try again later.']);
}
?>