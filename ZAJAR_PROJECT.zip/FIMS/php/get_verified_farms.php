<?php
session_start();
require 'db.php'; // Adjust path as necessary, relative to this script

header('Content-Type: application/json');

// Ensure only logged-in Extension Officers can access this
if (!isset($_SESSION['officer_id'])) { // Assuming 'officer_id' is set in session upon EO login
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access.', 'redirect' => '../eo_login.html']); // Added redirect
    exit;
}

// Get ward from GET request
$ward = isset($_GET['ward']) ? trim($_GET['ward']) : '';

try {
    if (empty($ward)) {
        // Handle case where ward is not provided (e.g., return an error or all verified farms)
        // For this specific request, we want to filter by ward, so we'll throw an error.
        throw new Exception("Ward parameter is missing.");
    }

    // Select all necessary farm details where status is 'Verified' AND for the specific ward
    $stmt = $conn->prepare("SELECT farm_id, farmer_id, farm_name, size_acres, village, ward, district, crop_type, date_registered FROM farms WHERE status = 'Verified' AND ward = ? ORDER BY date_registered DESC");

    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }

    $stmt->bind_param("s", $ward); // Bind the ward parameter
    $stmt->execute();
    $result = $stmt->get_result();

    $farms = [];
    while ($row = $result->fetch_assoc()) {
        $farms[] = $row;
    }
    $stmt->close();

    echo json_encode(['status' => 'success', 'farms' => $farms]);

} catch (Exception $e) {
    error_log("Error fetching verified farms: " . $e->getMessage()); // Log detailed error
    echo json_encode(['status' => 'error', 'message' => 'Failed to retrieve verified farms: ' . $e->getMessage()]); // Include error message for client
} finally {
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }
}
?>