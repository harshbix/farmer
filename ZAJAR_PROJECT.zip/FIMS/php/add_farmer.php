<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$response = ['status' => 'error', 'message' => 'An unknown error occurred.'];

$input = json_decode(file_get_contents('php://input'), true);

$first_name = $input['first_name'] ?? '';
$middle_name = $input['middle_name'] ?? '';
$last_name = $input['last_name'] ?? '';
$phone = $input['phone'] ?? '';
$email = $input['email'] ?? '';
$village = $input['village']?? '';
$ward = $input['ward'] ?? '';
$district = $input['district'] ?? '';
$password = $input['password'] ?? '';

if (empty($first_name) || empty($middle_name) || empty($last_name) || empty($email) || empty($village) || empty($ward)) {
    $response['message'] = 'All fields are required (First Name, Middle Name, Last Name, Phone, Email, Village and Ward).';
    echo json_encode($response);
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $response['message'] = 'Invalid email format.';
    echo json_encode($response);
    exit();
}

try {
    $stmt = $conn->prepare("SELECT farmer_id FROM farmers WHERE email = ?");
    if (!$stmt) {
        throw new Exception("Database prepare error (check email): " . $conn->error);
    }
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $response['message'] = 'A farmer with this email already exists.';
        echo json_encode($response);
        exit();
    }
    $stmt->close();

    // Generate unique Extension Officer ID (e.g. FMR-45821-792)
    $timestamp = time();
    $rand      = rand(100, 999);
    $farmer_id  = "FMR-" . substr($timestamp, -5) . "-" . $rand;

    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $conn->prepare("INSERT INTO farmers (farmer_id, first_name, middle_name, last_name, phone, email, village, ward, district, password_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        throw new Exception("Database prepare error (insert): " . $conn->error);
    }
    $stmt->bind_param("ssssssssss", $farmer_id, $first_name, $middle_name, $last_name, $phone, $email, $village, $ward, $district, $hashed_password);

    if ($stmt->execute()) {
        $response = ['status' => 'success', 'message' => 'Farmer added successfully!', 'farmer_id' => $farmer_id];
    } else {
        throw new Exception("Failed to add farmer: " . $stmt->error);
    }

    $stmt->close();

} catch (Exception $e) {
    error_log("Add Farmer error: " . $e->getMessage());
    $response['message'] = 'An internal server error occurred: ' . $e->getMessage();
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>