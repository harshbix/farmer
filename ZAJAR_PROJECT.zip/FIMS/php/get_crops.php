<?php
include 'db.php'; // Include your database connection file

header('Content-Type: application/json');

$response = ["status" => "error", "message" => ""];

try {
    $sql = "SELECT id, name FROM crops ORDER BY name ASC";
    $result = $conn->query($sql);

    $crops = [];
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $crops[] = $row;
        }
        $response["status"] = "success";
        $response["crops"] = $crops;
    } else {
        $response["message"] = "No crops found.";
        $response["crops"] = [];
    }
} catch (Exception $e) {
    $response["message"] = "Database error: " . $e->getMessage();
}

$conn->close();
echo json_encode($response);
?>