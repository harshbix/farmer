<?php
session_start();
header('Content-Type: application/json');

require_once 'db.php'; // Include your database connection

$response = ['status' => 'error', 'message' => 'Unauthorized'];

// Ensure only logged-in Extension Officers can access this
if (!isset($_SESSION['officer_id'])) {
    $response['redirect'] = '../eo_login.html'; // Redirect to login if not authenticated
    echo json_encode($response);
    exit();
}

$officer_id = $_SESSION['officer_id'];

try {
    // Prepare a statement to fetch farmers associated with the officer_id
    $stmt = $conn->prepare("SELECT farmer_id, first_name, middle_name, last_name, phone, village, ward FROM farmers WHERE officer_id = ? ORDER BY farmer_id DESC");
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }

    $stmt->bind_param("s", $officer_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $farmers = [];
    while ($row = $result->fetch_assoc()) {
        $farmers[] = $row;
    }
    $stmt->close();

    $response = ['status' => 'success', 'farmers' => $farmers];

} catch (Exception $e) {
    error_log("Error fetching district farmers: " . $e->getMessage());
    $response = ['status' => 'error', 'message' => 'Failed to retrieve farmers data.'];
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>