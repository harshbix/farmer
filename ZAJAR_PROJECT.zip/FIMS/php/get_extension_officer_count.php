<?php
session_start();
header('Content-Type: application/json');

require_once 'db.php';

$response = ['status' => 'error', 'message' => 'Unauthorized'];

if (!isset($_SESSION['officer_id'])) {
    $response['redirect'] = '../district_login.html';
    echo json_encode($response);
    exit();
}

// Assuming you want the total count of all extension officers, not specific to the logged-in officer's district
// If you want officers only in the logged-in officer's district, you'd need to fetch their district first.
try {
    // Use $conn (mysqli connection)
    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM extension_officers"); // Assuming 'extension_officers' is your table name
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    // No bind_param needed if counting all officers

    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $count = $row['count'];
    $stmt->close();

    $response = ['status' => 'success', 'count' => $count];

} catch (Exception $e) {
    error_log("Error fetching extension officer count: " . $e->getMessage());
    $response = ['status' => 'error', 'message' => 'Failed to retrieve extension officer count.'];
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>