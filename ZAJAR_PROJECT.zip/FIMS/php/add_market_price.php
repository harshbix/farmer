<?php
session_start();
header('Content-Type: application/json');
require_once 'db.php';

$response = ['status' => 'error', 'message' => 'Invalid request.'];

// Check if officer is logged in
if (!isset($_SESSION['officer_id'])) {
    $response['message'] = 'Unauthorized: Please log in.';
    http_response_code(401); // Unauthorized
    echo json_encode($response);
    exit();
}

// Get raw POST data
$input = json_decode(file_get_contents('php://input'), true);

$crop_name = $input['crop_name'] ?? '';
$unit = $input['unit'] ?? '';
$price_tsh = $input['price_tsh'] ?? '';
$market_name = $input['market_name'] ?? '';
$recorded_by_officer_id = $_SESSION['officer_id']; // Get officer_id from session

// Basic validation
if (empty($crop_name) || empty($unit) || !is_numeric($price_tsh) || empty($market_name)) {
    $response['message'] = 'All fields are required and price must be a number.';
    echo json_encode($response);
    exit();
}

try {
    $stmt = $conn->prepare("INSERT INTO market_prices (crop_name, unit, price_tsh, market_name, recorded_by_officer_id) VALUES (?, ?, ?, ?, ?)");
    if (!$stmt) {
        throw new Exception("Database prepare error: " . $conn->error);
    }

    // FIX: Changed 'ssds' to 'ssdss' to match 5 bind variables
    $stmt->bind_param("ssdss", $crop_name, $unit, $price_tsh, $market_name, $recorded_by_officer_id);

    if ($stmt->execute()) {
        $response = ['status' => 'success', 'message' => 'Market price added successfully.', 'id' => $conn->insert_id];
    } else {
        throw new Exception("Execute failed: " . $stmt->error);
    }

    $stmt->close();

} catch (Exception $e) {
    error_log("Add Market Price error: " . $e->getMessage());
    $response['message'] = 'An internal server error occurred: ' . $e->getMessage();
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
echo json_encode($response);
?>