<?php
session_start();
header('Content-Type: application/json');

require_once 'db.php';

$response = ['status' => 'error', 'message' => 'Unauthorized'];

// Still ensure only logged-in officers (district officers in this context) can access
if (!isset($_SESSION['officer_id'])) {
    $response['redirect'] = '../eo_login.html';
    echo json_encode($response);
    exit();
}

try {
    // Count all farmers, as the system is for one district and no officer_id column exists in 'farmers'
    $stmt = $conn->prepare("SELECT COUNT(*) AS count FROM farmers");
    if (!$stmt) {
        throw new Exception("Failed to prepare statement: " . $conn->error);
    }
    // No bind_param needed as there's no WHERE clause based on officer_id

    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $count = $row['count'];
    $stmt->close();

    $response = ['status' => 'success', 'count' => $count];

} catch (Exception $e) {
    error_log("Error fetching farmer count (single district): " . $e->getMessage());
    $response = ['status' => 'error', 'message' => 'Failed to retrieve farmer count.'];
} finally {
    if (isset($conn) && $conn) {
        $conn->close();
    }
}

echo json_encode($response);
?>