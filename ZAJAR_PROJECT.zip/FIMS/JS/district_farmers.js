document.addEventListener("DOMContentLoaded", () => {
    const tableBody = document.getElementById("farmerTableBody");
    const toggleBtn = document.getElementById("toggleSidebar");
    const sidebar = document.getElementById("sidebar");
    const main = document.getElementById("main");
    const confirmDeletePopup = document.getElementById("confirmDeletePopup");
    const confirmDeleteBtn = document.getElementById("confirmDeleteBtn");
    const cancelDeleteBtn = document.getElementById("cancelDeleteBtn");
    let farmerIdToDelete = null; // To store the ID of the farmer to be deleted

    // Toggle sidebar visibility
    if (toggleBtn) {
        toggleBtn.addEventListener("click", function () {
            sidebar.classList.toggle("collapsed");
            main.classList.toggle("collapsed");
        });
    }

    // Function to add a single farmer row to the table
    function addFarmerToTable(farmer) {
        const row = tableBody.insertRow();
        row.dataset.farmerId = farmer.farmer_id; // Store farmer_id on the row

        row.innerHTML = `
            <td>${farmer.farmer_id || ''}</td>
            <td>${farmer.first_name || ''} ${farmer.middle_name || ''} ${farmer.last_name || ''}</td>
            <td>${farmer.phone || ''}</td>
            <td>${farmer.village || ''}</td>
            <td>${farmer.ward || ''}</td>
            <td class="action-buttons">
                <button class="delete-btn">Delete</button>
            </td>
        `;

        // Add event listener for the delete button in this row
        const deleteButton = row.querySelector(".delete-btn");
        if (deleteButton) {
            deleteButton.addEventListener("click", () => {
                farmerIdToDelete = farmer.farmer_id;
                confirmDeletePopup.style.display = "flex"; // Show the confirmation popup
            });
        }
    }

    // Function to fetch and display all farmers
    async function fetchAndDisplayFarmers() {
        try {
            const response = await fetch('php/district_get_farmers.php', {
                method: 'POST' // Or GET, depending on your PHP
            });
            const data = await response.json();

            if (data.status === 'success' && data.farmers) {
                tableBody.innerHTML = ''; // Clear existing table rows
                data.farmers.forEach(addFarmerToTable);
            } else if (data.status === 'error' && data.redirect) {
                window.location.href = data.redirect; // Redirect if session expired or unauthorized
            } else {
                console.error('Failed to load farmers:', data.message || 'No farmers found.');
                tableBody.innerHTML = '<tr><td colspan="6">No farmers registered yet or failed to load.</td></tr>';
            }
        } catch (error) {
            console.error('Error fetching farmers:', error);
            tableBody.innerHTML = '<tr><td colspan="6">Error loading farmers.</td></tr>';
        }
    }

    // Function to fetch and display the officer ID
    async function fetchOfficerId() {
        try {
            const officerProfileResponse = await fetch('php/get_district_profile.php');
            const officerProfileData = await officerProfileResponse.json();

            if (officerProfileData.status === 'success' && officerProfileData.officer && officerProfileData.officer.officer_id) {
                document.querySelector(".officer-id").textContent = officerProfileData.officer.officer_id;
            } else {
                console.error('Failed to fetch districtofficer ID:', officerProfileData.message || 'Unknown error');
                document.querySelector(".officer-id").textContent = 'Officer ID: N/A';
                handleAuthError(officerProfileData); // Pass the data to the handler
            }
        } catch (error) {
            console.error('Error fetching officer profile:', error);
            document.querySelector(".officer-id").textContent = 'Officer ID: Error';
        }
    }

    // Event listener for the confirm delete button
    if (confirmDeleteBtn) {
        confirmDeleteBtn.addEventListener("click", async () => {
            if (farmerIdToDelete) {
                try {
                    const formData = new FormData();
                    formData.append('farmer_id', farmerIdToDelete);

                    const response = await fetch('php/delete_farmer.php', {
                        method: 'POST',
                        body: formData
                    });
                    const data = await response.json();

                    if (data.status === 'success') {
                        alert(data.message);
                        fetchAndDisplayFarmers(); // Refresh the list
                    } else if (data.status === 'error' && data.redirect) {
                        window.location.href = data.redirect; // Redirect if session expired
                    } else {
                        alert(data.message || 'Failed to delete farmer.');
                    }
                } catch (error) {
                    console.error('Error deleting farmer:', error);
                    alert('An error occurred during deletion. Please try again.');
                } finally {
                    confirmDeletePopup.style.display = "none"; // Hide popup
                    farmerIdToDelete = null; // Reset variable
                }
            }
        });
    }

    if (cancelDeleteBtn) {
        cancelDeleteBtn.addEventListener("click", () => {
            confirmDeletePopup.style.display = "none"; // Hide popup
            farmerIdToDelete = null; // Reset variable
        });
    }

    // Initial load of farmers when the page is ready
    fetchAndDisplayFarmers();
    fetchOfficerId();

    // Set active link in sidebar
    const navLinks = document.querySelectorAll('.sidebar a');
    navLinks.forEach(link => {
        if (link.getAttribute('href').includes('district_farmers.html')) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
});