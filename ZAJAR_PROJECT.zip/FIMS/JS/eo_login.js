document.addEventListener('DOMContentLoaded', function() {
    const loginForm = document.getElementById('loginForm');
    const loginMessage = document.getElementById('loginMessage');

    if (loginMessage) {
        loginMessage.textContent = ''; 
        loginMessage.style.display = 'none';
    }

    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault();

            loginMessage.textContent = ''; 
            loginMessage.style.color = 'red';
            loginMessage.style.display = 'none';

            const formData = new FormData(loginForm);
            fetch('php/eo_login.php', { 
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    loginMessage.style.color = 'green';
                    loginMessage.textContent = data.message;
                    loginMessage.style.display = 'block';
                    
                    if (data.redirect) {
                        window.location.href = data.redirect;
                    } else {
                        window.location.href = 'php/eo_dashboard.php'; 
                    }
                } else {
                    loginMessage.textContent = data.message || 'Login failed. Please try again.';
                    loginMessage.style.display = 'block'; // Show error message
                }
            })
            .catch(error => {
                console.error('Error:', error);
                loginMessage.textContent = 'An error occurred. Please try again later.';
                loginMessage.style.display = 'block'; // Show error message
            });
        });
    }
});