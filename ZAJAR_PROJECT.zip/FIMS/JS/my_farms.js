document.addEventListener('DOMContentLoaded', function() {
    const toggleSidebarBtn = document.getElementById('toggleSidebar');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('main');
    const districtSelect = document.getElementById("district");
    const wardSelect = document.getElementById("ward");
    const villageSelect = document.getElementById("village");
    const openFormBtn = document.getElementById('openFormBtn');
    const popupForm = document.getElementById('popupForm');
    const cancelFormBtn = document.getElementById('cancelFormBtn');
    const farmForm = document.getElementById('farmForm');
    const farmTableBody = document.getElementById('farmTableBody');
    const cropTypeSelect = document.getElementById('cropType');

    // Function to populate a dropdown
    function populateDropdown(selectElement, data, defaultOptionText) {
        selectElement.innerHTML = `<option value="">${defaultOptionText}</option>`;
        data.forEach(item => {
            const option = document.createElement("option");
            option.value = item.id;
            option.textContent = item.name;
            selectElement.appendChild(option);
        });
    }

    // Function to fetch crops for farm form
    function fetchCrops() {
        fetch('php/get_crops.php')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success' && data.crops) {
                    populateDropdown(cropTypeSelect, data.crops, "Select Crop Type");
                } else {
                    console.error("Error loading crops:", data.message);
                    cropTypeSelect.innerHTML = '<option value="">Select Crop Type</option>';
                }
            })
            .catch(error => {
                console.error("Error fetching crops:", error);
                cropTypeSelect.innerHTML = '<option value="">Select Crop Type</option>';
            });
    }

    // Function to fetch districts from an API
    function fetchDistricts() {
        fetch('php/get_districts.php') // Your API endpoint to fetch districts
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                populateDropdown(districtSelect, data, "Select District");
                // Removed the automatic selection of Kahama here
            })
            .catch(error => {
                console.error("Error fetching districts:", error);
                alert("An error occurred while fetching districts.");
            });
    }

    // Function to fetch wards based on district ID
    function fetchWards(districtId) {
        if (!districtId) {
            wardSelect.innerHTML = '<option value="">Select Ward</option>';
            villageSelect.innerHTML = '<option value="">Select Village</option>';
            return;
        }
        fetch(`php/get_wards.php?district_id=${districtId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                populateDropdown(wardSelect, data, "Select Ward");
                villageSelect.innerHTML = '<option value="">Select Village</option>';
            })
            .catch(error => {
                console.error("Error fetching wards:", error);
                alert("An error occurred while fetching wards.");
            });
    }

    // Function to fetch villages based on ward ID
    function fetchVillages(wardId) {
        if (!wardId) {
            villageSelect.innerHTML = '<option value="">Select Village</option>';
            return;
        }
        fetch(`php/get_villages.php?ward_id=${wardId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                populateDropdown(villageSelect, data, "Select Village");
            })
            .catch(error => {
                console.error("Error fetching villages:", error);
                alert("An error occurred while fetching villages.");
            });
    }

    // Event listeners for farm form dropdowns
    districtSelect.addEventListener("change", function() {
        fetchWards(this.value);
    });

    wardSelect.addEventListener("change", function() {
        fetchVillages(this.value);
    });

    // Function to add a single farm row to the table
    function addFarmToTable(farm, index) {
        const row = farmTableBody.insertRow();
        row.dataset.farmId = farm.farm_id;

        row.innerHTML = `
            <td>${index}</td>
            <td>${farm.farm_name}</td>
            <td>${farm.size_acres}</td>
            <td>${farm.crop_type || 'N/A'}</td>
            <td>${farm.village}</td>
            <td>${farm.ward}</td>
            <td>${farm.district}</td>
            <td><span class="status-${farm.status.toLowerCase()}">${farm.status}</span></td>
        `;
    }

    // Function to fetch and display farms
    function fetchAndDisplayFarms() {
        farmTableBody.innerHTML = '<tr><td colspan="8">Loading farms...</td></tr>';

        fetch('php/get_my_farms.php')
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success' && data.farms) {
                farmTableBody.innerHTML = '';
                if (data.farms.length > 0) {
                    data.farms.forEach((farm, index) => {
                        addFarmToTable(farm, index + 1);
                    });
                } else {
                    farmTableBody.innerHTML = '<tr><td colspan="8">No farms registered yet.</td></tr>';
                }
            } else {
                console.error('Failed to load farms:', data.message || 'No farms found.');
                farmTableBody.innerHTML = `<tr><td colspan="8">${data.message || 'No farms found.'}</td></tr>`;
            }
        })
        .catch(error => {
            console.error('Error fetching farms:', error);
            farmTableBody.innerHTML = '<tr><td colspan="8">Error loading farms. Please check server logs.</td></tr>';
        });
    }

    // Sidebar toggle functionality
    toggleSidebarBtn.addEventListener('click', function() {
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('collapsed');
    });

    // Form submission for adding new farm
    openFormBtn.addEventListener('click', () => {
        popupForm.style.display = 'flex';
        farmForm.reset();
        // Reset dropdowns and load initial data
        wardSelect.innerHTML = '<option value="">Select Ward</option>';
        villageSelect.innerHTML = '<option value="">Select Village</option>';
        fetchCrops();
        fetchDistricts();
    });

    cancelFormBtn.addEventListener('click', () => {
        popupForm.style.display = 'none';
    });

    farmForm.addEventListener('submit', async function(event) {
        event.preventDefault();

        const formData = new FormData(farmForm);
             
        // Append the selected text values for district, ward, and village
        // as the PHP script expects name strings, not just IDs.
        formData.append('district_name', districtSelect.options[districtSelect.selectedIndex].text);
        formData.append('ward_name', wardSelect.options[wardSelect.selectedIndex].text);
        formData.append('village_name', villageSelect.options[villageSelect.selectedIndex].text);
        formData.append('crop_type', cropTypeSelect.options[cropTypeSelect.selectedIndex].text);

        try {
            const response = await fetch('php/register_farm.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.status === 'success') {
                alert(data.message);
                popupForm.style.display = 'none';
                fetchAndDisplayFarms();
            } else {
                alert(data.message || 'Farm registration failed.');
                console.error('Farm registration error:', data.message);
            }
        } catch (error) {
            console.error('Error registering farm:', error);
            alert('An error occurred during farm registration.');
        }
    });

    // Initial data fetches on page load
    fetch('php/get_farmer_data.php', {
        method: 'POST'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.status === 'success' && data.data) {
            const farmer = data.data;
            const topBarFarmerIdElement = document.getElementById('displayTopBarFarmerId');
            if (topBarFarmerIdElement) {
                topBarFarmerIdElement.innerText = farmer.farmer_id || '';
            }
            fetchAndDisplayFarms();
        } else {
            console.error('Server response error (get_farmer_data.php):', data.message || 'Unknown error from server.');
            alert(data.message || 'Failed to load farmer data. Please try logging in again.');
            window.location.href = 'login.html';
        }
    })
    .catch(error => {
        console.error('Fetch error (get_farmer_data.php):', error);
        alert('Could not load farmer data. Please try logging in again.');
        window.location.href = 'login.html';
    });

    // Event listener for sidebar links to manage active class
    const navLinks = document.querySelectorAll('.sidebar a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
        });
    });

    const activePath = window.location.pathname;
    navLinks.forEach(link => {
        if (link.href.includes(activePath)) {
            link.classList.add('active');
        }
    });
});