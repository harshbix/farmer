document.addEventListener("DOMContentLoaded", () => {
  const popupForm = document.getElementById("popupForm");
  const addPriceBtn = document.getElementById("addPriceBtn");
  const cancelBtn = document.getElementById("cancelFormBtn");
  const priceForm = document.getElementById("priceForm");
  const priceTableBody = document.getElementById("priceTableBody");
  const toggleBtn = document.getElementById("toggleSidebar");
  const sidebar = document.getElementById("sidebar");
  const main = document.getElementById("main");
  const officerIdSpan = document.querySelector(".officer-id");

  // New dropdown elements (updated marketSelect to regionSelect)
  const cropSelect = document.getElementById("cropSelect");
  const regionSelect = document.getElementById("regionSelect"); // Changed from marketSelect

  let editingRow = null;

  toggleBtn.addEventListener("click", function () {
    sidebar.classList.toggle("collapsed");
    main.classList.toggle("collapsed");
  });

  async function displayOfficerId() {
    try {
      const response = await fetch('php/get_district_profile.php');

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.status === 'success' && data.officer && data.officer.officer_id) {
        if (officerIdSpan) {
          officerIdSpan.textContent = data.officer.officer_id;
        }
      } else {
        if (officerIdSpan) {
          officerIdSpan.textContent = "N/A";
        }
        console.warn("Could not retrieve Officer ID:", data.message);
        if (data.redirect) {
          window.location.href = data.redirect;
        }
      }
    } catch (error) {
      console.error("Error fetching Officer ID:", error);
      if (officerIdSpan) {
        officerIdSpan.textContent = "Error";
      }
    }
  }

  function populateSelect(selectElement, data, defaultOptionText) {
    selectElement.innerHTML = `<option value="">${defaultOptionText}</option>`;
    data.forEach(item => {
      const option = document.createElement('option');
      option.value = item.value;
      option.textContent = item.text;
      selectElement.appendChild(option);
    });
  }

  async function fetchCrops() {
    try {
      const response = await fetch('php/get_crops.php');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      if (data.status === 'success') {
        const crops = data.crops.map(crop => ({ value: crop.name, text: crop.name }));
        populateSelect(cropSelect, crops, "Select Crop");
      } else {
        console.error("Failed to fetch crops:", data.message);
      }
    } catch (error) {
      console.error("Error fetching crops:", error);
    }
  }

  // Function to fetch regions from the backend (changed from fetchMarkets)
  async function fetchRegions() {
    try {
      const response = await fetch('php/get_regions.php'); // New API endpoint
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();
      if (data.status === 'success') {
        // Assuming regions are returned with 'id' and 'name'
        const regions = data.regions.map(region => ({ value: region.name, text: region.name }));
        populateSelect(regionSelect, regions, "Select Region"); // Changed default option text
      } else {
        console.error("Failed to fetch regions:", data.message);
      }
    } catch (error) {
      console.error("Error fetching regions:", error);
    }
  }

  function renderRow(data) {
    const row = document.createElement("tr");
    row.dataset.id = data.id;
    row.innerHTML = `
      <td>${data.crop_name}</td>
      <td>${data.unit}</td>
      <td>${data.price_tsh}</td>
      <td>${data.market_name}</td> <td>
        <button class="edit-btn">Edit</button>
        <button class="delete-btn">Delete</button>
      </td>
    `;

    row.querySelector(".edit-btn").addEventListener("click", () => {
      document.getElementById("formTitle").textContent = "Edit Market Price";
      cropSelect.value = data.crop_name;
      document.getElementById("unit").value = data.unit;
      document.getElementById("price").value = data.price_tsh;
      regionSelect.value = data.market_name; // Use market_name to pre-select region
      editingRow = row;
      popupForm.style.display = "flex";
    });

    row.querySelector(".delete-btn").addEventListener("click", async () => {
      if (confirm("Are you sure you want to delete this market price?")) {
        const priceId = row.dataset.id;
        try {
          const response = await fetch('php/delete_market_price.php', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: priceId })
          });

          const result = await response.json();

          if (result.status === 'success') {
            row.remove();
            alert(result.message);
          } else {
            alert("Failed to delete price: " + result.message);
          }
        } catch (error) {
          console.error("Error deleting price:", error);
          alert("An error occurred while deleting the price.");
        }
      }
    });

    priceTableBody.appendChild(row);
  }

  async function fetchMarketPrices() {
    try {
      const response = await fetch('php/get_market_prices.php');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();

      if (data.status === 'success') {
        priceTableBody.innerHTML = '';
        if (data.prices.length > 0) {
          data.prices.forEach(price => renderRow(price));
        } else {
          priceTableBody.innerHTML = '<tr><td colspan="5">No market prices recorded yet.</td></tr>';
        }
      } else {
        console.error("Server error fetching prices:", data.message);
        priceTableBody.innerHTML = `<tr><td colspan="5">Error loading prices: ${data.message}</td></tr>`;
      }
    } catch (error) {
      console.error("Error fetching market prices:", error);
      priceTableBody.innerHTML = '<tr><td colspan="5">Failed to load market prices. Please try again.</td></tr>';
    }
  }

  priceForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const crop = cropSelect.value;
    const unit = document.getElementById("unit").value.trim();
    const price = document.getElementById("price").value.trim();
    const region = regionSelect.value; // Get selected region value

    if (!crop || !unit || !price || !region) {
      alert("Please fill in all fields.");
      return;
    }

    const priceData = {
      crop_name: crop,
      unit: unit,
      price_tsh: parseFloat(price),
      market_name: region // Send region name as market_name to backend
    };

    let url = 'php/add_market_price.php';
    let method = 'POST';

    if (editingRow) {
      url = 'php/update_market_price.php';
      priceData.id = editingRow.dataset.id;
    }

    try {
      const response = await fetch(url, {
        method: method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(priceData)
      });

      const result = await response.json();

      if (result.status === 'success') {
        alert(result.message);
        popupForm.style.display = "none";
        priceForm.reset();
        document.getElementById("formTitle").textContent = "Add Market Price";
        editingRow = null;
        fetchMarketPrices();
      } else {
        alert("Operation failed: " + result.message);
      }
    } catch (error) {
      console.error("Error saving market price:", error);
      alert("An error occurred while saving the market price.");
    }
  });

  addPriceBtn.addEventListener("click", () => {
    editingRow = null;
    document.getElementById("formTitle").textContent = "Add Market Price";
    priceForm.reset();
    popupForm.style.display = "flex";
  });

  cancelBtn.addEventListener("click", () => {
    popupForm.style.display = "none";
    priceForm.reset();
    editingRow = null;
    document.getElementById("formTitle").textContent = "Add Market Price";
  });

  displayOfficerId();
  fetchMarketPrices();
  fetchCrops();
  fetchRegions(); // Call fetchRegions instead of fetchMarkets
});