document.addEventListener("DOMContentLoaded", () => {
    const toggleSidebarBtn = document.getElementById('toggleSidebar');
    const priceTableBody = document.getElementById("priceTableBody"); // Get the table body for prices

    // Function to fetch and display market prices
  async function fetchMarketPrices() {
    try {
      // Assuming api/get_market_prices.php is the correct path for market prices
      const response = await fetch('php/farmer_market_prices.php');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();

      if (data.status === 'success') {
        priceTableBody.innerHTML = ''; // Clear existing table content
        if (data.prices.length > 0) {
          data.prices.forEach((price, index) => { // Added index for '#' column
            const row = document.createElement("tr");
            row.innerHTML = `
              <td>${index + 1}</td> <td>${price.crop_name}</td>
              <td>${price.unit}</td>
              <td>${price.price_tsh}</td>
              <td>${price.market_name}</td>
              <td>${price.updated_at}</td>
            `;
            priceTableBody.appendChild(row);
          });
        } else {
          priceTableBody.innerHTML = '<tr><td colspan="5">No market prices recorded yet.</td></tr>'; //
        }
      } else {
        console.error("Server error fetching prices:", data.message);
        priceTableBody.innerHTML = `<tr><td colspan="5">Error loading prices: ${data.message}</td></tr>`; //
      }
    } catch (error) {
      console.error("Error fetching market prices:", error);
      priceTableBody.innerHTML = '<tr><td colspan="5">Failed to load market prices. Please try again.</td></tr>'; //
    }
  }

    // First, fetch farmer data to ensure the session is active and get farmer details
    fetch('php/get_farmer_data.php', {
        method: 'POST'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.status === 'success' && data.data) {
            const farmer = data.data;
            const topBarFarmerIdElement = document.getElementById('displayTopBarFarmerId');
            if (topBarFarmerIdElement) {
                topBarFarmerIdElement.innerText = farmer.farmer_id || '';
            }

        } else {
            console.error('Server response error (get_farmer_data.php):', data.message || 'Unknown error from server.');
            alert(data.message || 'Failed to load farmer data. Please try logging in again.');
            window.location.href = 'login.html';
        }
    })
    .catch(error => {
        console.error('Fetch error (get_farmer_data.php):', error);
        alert('Could not load farmer data. Please try logging in again.');
        window.location.href = 'login.html';
    });

  fetchMarketPrices();

    toggleSidebarBtn.addEventListener('click', function() {
        sidebar.classList.toggle('collapsed');
        mainContent.classList.toggle('collapsed');
    });
    console.log("Market prices loaded.");
});
