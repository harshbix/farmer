document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("outputForm");
    const toggleBtn = document.getElementById("toggleSidebar");
    const sidebar = document.getElementById("sidebar");
    const main = document.getElementById("main");
    const farmNameSelect = document.getElementById("farmName");
    const cropNameSelect = document.getElementById("cropName");
    const outputsTableBody = document.getElementById("outputsTableBody");

    // Modal elements
    const outputFormModal = document.getElementById("outputFormModal");
    const addOutputBtn = document.getElementById("addOutputBtn");
    const closeButton = document.querySelector("#outputFormModal .close-button");
    const cancelOutputBtn = document.getElementById("cancelOutputBtn");

    // Sidebar toggle functionality
    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("collapsed");
        main.classList.toggle("collapsed");
    });

    // Function to handle redirection on authentication failure from AJAX responses
    function handleAuthError(data) {
        if (data.status === 'error' && data.redirect) {
            window.location.href = data.redirect;
        }
    }

    // Function to populate a dropdown
    function populateDropdown(selectElement, data, defaultOptionText) {
        selectElement.innerHTML = `<option value="">${defaultOptionText}</option>`;
        data.forEach(item => {
            const option = document.createElement("option");
            option.value = item.id;
            option.textContent = item.name;
            selectElement.appendChild(option);
        });
    }

    // Function to show modal
    function showModal() {
        outputFormModal.style.display = "flex";
        outputFormModal.classList.add("active");
    }

    // Function to hide modal
    function hideModal() {
        outputFormModal.style.display = "none";
        outputFormModal.classList.remove("active");
        form.reset();
        cropNameSelect.innerHTML = '<option value="">Select Crop Name</option>';
    }

    // Function to fetch farm names for farm form
    function fetchFarms() {
        fetch('php/get_farms.php')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success' && data.farms) {
                    populateDropdown(farmNameSelect, data.farms.map(farm => ({
                        id: farm.farm_id, 
                        name: farm.farm_name
                    })), "Select Farm Name");
                } else {
                    console.error("Error loading farms:", data.message);
                    farmNameSelect.innerHTML = '<option value="">Select Farm Name</option>';
                }
            })
            .catch(error => {
                console.error("Error fetching farms:", error);
                farmNameSelect.innerHTML = '<option value="">Select Farm Name</option>';
            });
    }

    // Function to fetch crops based on selected farm
    function fetchCrops(farmId) {
        if (!farmId) {
            cropNameSelect.innerHTML = '<option value="">Select Crop Name</option>';
            return;
        }
        fetch(`php/get_crops_by_farm.php?farm_id=${farmId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success' && data.crops) {
                    populateDropdown(cropNameSelect, data.crops.map(crop => ({
                        id: crop.crop_type, 
                        name: crop.crop_type
                    })), "Select Crop Name");
                } else {
                    console.error("Error loading crops:", data.message);
                    cropNameSelect.innerHTML = '<option value="">Select Crop Name</option>';
                }
            })
            .catch(error => {
                console.error("Error fetching crops:", error);
                cropNameSelect.innerHTML = '<option value="">Select Crop Name</option>';
            });
    }

    // Function to fetch and display farm outputs
    function fetchOutputs() {
        fetch('php/get_farmer_outputs.php')
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success' && data.outputs) {
                    outputsTableBody.innerHTML = '';
                    if (data.outputs.length === 0) {
                        outputsTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px;">No outputs registered yet.</td></tr>';
                    } else {
                        data.outputs.forEach((output, index) => {
                            const row = outputsTableBody.insertRow();
                            row.insertCell(0).textContent = index + 1;
                            row.insertCell(1).textContent = output.farm_id;
                            row.insertCell(2).textContent = output.crop_name;
                            row.insertCell(3).textContent = parseFloat(output.quantity).toFixed(2);
                            row.insertCell(4).textContent = formatDateTime(output.recorded_at);
                        });
                    }
                } else {
                    console.error("Error loading outputs:", data.message);
                    outputsTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px;">No outputs found.</td></tr>';
                }
                handleAuthError(data);
            })
            .catch(error => {
                console.error("Error fetching outputs:", error);
                outputsTableBody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 20px;">Error loading outputs.</td></tr>';
            });
    }

    // Helper function to format date
    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    // Helper function to format date and time
    function formatDateTime(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    // Initialize page - fetch farmer data first
    fetch('php/get_farmer_data.php', {
        method: 'POST'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.status === 'success' && data.data) {
            const farmer = data.data;
            const topBarFarmerIdElement = document.getElementById('displayTopBarFarmerId');
            if (topBarFarmerIdElement) {
                topBarFarmerIdElement.innerText = farmer.farmer_id || '';
            }
            // Fetch outputs and farms after farmer data is loaded
            fetchOutputs();
            fetchFarms();
        } else {
            console.error('Server response error:', data.message || 'Unknown error from server.');
            handleAuthError(data);
            if (!data.redirect) {
                alert('Could not load farmer data. Please try logging in again.');
                window.location.href = 'login.html';
            }
        }
    })
    .catch(error => {
        console.error('Fetch error:', error);
        alert('Could not load farmer data. Please try logging in again.');
        window.location.href = 'login.html';
    });

    // Event listener for farm selection change
    farmNameSelect.addEventListener('change', (event) => {
        const selectedFarmId = event.target.value;
        fetchCrops(selectedFarmId);
    });

    // Modal event listeners
    addOutputBtn.addEventListener("click", () => {
        showModal();
    });

    closeButton.addEventListener("click", () => {
        hideModal();
    });

    cancelOutputBtn.addEventListener("click", () => {
        hideModal();
    });

    // Close modal when clicking outside
    window.addEventListener("click", (event) => {
        if (event.target === outputFormModal) {
            hideModal();
        }
    });

    // Close modal on Escape key
    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && outputFormModal.style.display === "flex") {
            hideModal();
        }
    });

    // Form submission handler
    form.addEventListener("submit", function(event) {
        event.preventDefault();

        // Basic validation
        const farmName = farmNameSelect.value;
        const cropName = cropNameSelect.value;
        const quantity = document.getElementById("quantity").value;
        const harvestDate = document.getElementById("harvestDate").value;

        if (!farmName || !cropName || !quantity || !harvestDate) {
            alert("Please fill in all fields.");
            return;
        }

        if (parseFloat(quantity) <= 0) {
            alert("Quantity must be greater than 0.");
            return;
        }

        // Submit form
        const formData = new FormData(form);
        
        fetch('php/register_output.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                alert(data.message);
                hideModal();
                fetchOutputs(); // Refresh the outputs table
            } else {
                alert(data.message || 'Operation failed.');
            }
            handleAuthError(data);
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred. Please try again. ' + error.message);
        });
    });
});