document.addEventListener("DOMContentLoaded", () => {
    const sidebar = document.getElementById("sidebar");
    const toggleSidebar = document.getElementById("toggleSidebar");
    const farmerFormPopup = document.getElementById("farmerForm"); // The add farmer form popup
    const addFarmerForm = document.getElementById("addFarmerForm"); // The form itself
    const farmersTableBody = document.getElementById("farmersTable"); // The tbody for farmers table

    // Custom Delete Confirmation Pop-up elements
    const deleteFarmerConfirmPopup = document.getElementById('deleteFarmerConfirmPopup');
    const confirmFarmerMessage = document.getElementById('confirmFarmerMessage');
    const confirmDeleteFarmerBtn = document.getElementById('confirmDeleteFarmerBtn');
    const cancelDeleteFarmerBtn = document.getElementById('cancelDeleteFarmerBtn');

    let farmerIdToDelete = null; // To store the ID of the farmer to be deleted
    let farmerNameToDelete = null; // To store the name for the confirmation message
    let officerAssignedWard = null; // New: To store the officer's assigned ward

    // References to the new dropdowns
    const districtSelect = document.getElementById("district");
    const wardSelect = document.getElementById("ward");
    const villageSelect = document.getElementById("village");

    toggleSidebar.addEventListener("click", () => {
        sidebar.classList.toggle("collapsed");
        document.getElementById('main').classList.toggle('collapsed');
    });

    document.getElementById("addFarmerBtn").addEventListener("click", () => {
        addFarmerForm.reset(); // Clear form on open
        fetchDistricts(); // Fetch districts when the add farmer form opens
        farmerFormPopup.style.display = "flex";
    });

    document.getElementById("cancelFarmerFormBtn").addEventListener("click", () => {
        farmerFormPopup.style.display = "none";
        addFarmerForm.reset();
    });

    // Function to handle redirection on authentication failure from AJAX responses
    function handleAuthError(data) {
        if (data.status === 'error' && data.redirect) {
            window.location.href = data.redirect;
        }
    }

    // Function to populate a dropdown
    function populateDropdown(selectElement, data, defaultOptionText) {
        selectElement.innerHTML = `<option value="">${defaultOptionText}</option>`;
        data.forEach(item => {
            const option = document.createElement("option");
            // Assuming the data has 'id' and 'name' fields, adjust if your API returns different keys
            option.value = item.id;
            option.textContent = item.name;
            selectElement.appendChild(option);
        });
    }

    // Function to fetch districts from an API
    function fetchDistricts() {
        fetch('php/get_districts.php') // Your API endpoint to fetch districts
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                populateDropdown(districtSelect, data, "Select District");
            })
            .catch(error => {
                console.error("Error fetching districts:", error);
                // alert("An error occurred while fetching districts."); // Avoid alerts in production
            });
    }

    // Function to fetch wards based on district ID
    function fetchWards(districtId) {
        if (!districtId) {
            wardSelect.innerHTML = '<option value="">Select Ward</option>';
            villageSelect.innerHTML = '<option value="">Select Village</option>';
            return;
        }
        fetch(`php/get_wards.php?district_id=${districtId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                populateDropdown(wardSelect, data, "Select Ward");
                villageSelect.innerHTML = '<option value="">Select Village</option>'; // Clear villages when ward changes
            })
            .catch(error => {
                console.error("Error fetching wards:", error);
                // alert("An error occurred while fetching wards.");
            });
    }

    // Function to fetch villages based on ward ID
    function fetchVillages(wardId) {
        if (!wardId) {
            villageSelect.innerHTML = '<option value="">Select Village</option>';
            return;
        }
        fetch(`php/get_villages.php?ward_id=${wardId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                populateDropdown(villageSelect, data, "Select Village");
            })
            .catch(error => {
                console.error("Error fetching villages:", error);
                // alert("An error occurred while fetching villages.");
            });
    }

    // Event listeners for dropdowns
    if (districtSelect) {
        districtSelect.addEventListener("change", function() {
            fetchWards(this.value);
        });
    }

    if (wardSelect) {
        wardSelect.addEventListener("change", function() {
            fetchVillages(this.value);
        });
    }

    // Handle Add Farmer form submission
    addFarmerForm.addEventListener("submit", async function (e) {
        e.preventDefault();

        // Get values from the form fields
        const firstName = document.getElementById("firstName").value;
        const middleName = document.getElementById("middleName").value;
        const lastName = document.getElementById("lastName").value;
        const phone = document.getElementById("phone").value;
        const email = document.getElementById("email").value;

        // Get the selected text content (name) from the dropdowns
        const district = districtSelect.options[districtSelect.selectedIndex].textContent;
        const ward = wardSelect.options[wardSelect.selectedIndex].textContent;
        const village = villageSelect.options[villageSelect.selectedIndex].textContent;

        // Let's send a default password for initial registration
        const defaultPassword = "Password123";

        try {
            const response = await fetch('php/add_farmer.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json' // Important: specify JSON content type
                },
                body: JSON.stringify({
                    first_name: firstName,
                    middle_name: middleName,
                    last_name: lastName,
                    phone: phone,
                    email: email,
                    village: village,
                    ward: ward,
                    district: district,
                    password: defaultPassword
                })
            });

            const data = await response.json();

            if (data.status === 'success') {
                alert(data.message); // Consider using a custom modal instead of alert
                farmerFormPopup.style.display = "none";
                addFarmerForm.reset();
                // Pass the officer's ward when refreshing the list
                if (officerAssignedWard) {
                    fetchAndDisplayFarmers(officerAssignedWard);
                } else {
                    fetchAndDisplayFarmers(); // Fallback if ward not yet determined
                }
            } else {
                alert(data.message || 'Failed to add farmer.');
            }
        } catch (error) {
            console.error('Error adding farmer:', error);
            alert('An error occurred while adding the farmer. Please try again.');
        }
    });

    // Function to add a single farmer row to the table
    function addFarmerToTable(farmer) {
        const row = document.createElement("tr");
        row.dataset.farmerId = farmer.farmer_id; // Store farmer_id on the row

        row.innerHTML = `
            <td>${farmer.farmer_id || ''}</td>
            <td>${farmer.first_name || ''} ${farmer.middle_name ? farmer.middle_name + ' ' : ''}${farmer.last_name || ''}</td>
            <td>${farmer.phone || ''}</td>
            <td>${farmer.email || ''}</td>
            <td>${farmer.village || ''}</td>
            <td>${farmer.ward || ''}</td>
            <td>${farmer.district || ''}</td>
            <td class="action-btns">
                <button class="delete-btn" data-farmer-id="${farmer.farmer_id}" data-farmer-name="${farmer.first_name || ''} ${farmer.last_name || ''}">Delete</button>
            </td>
        `;
        farmersTableBody.appendChild(row);
    }

    // Function to fetch and display farmers, now accepting an optional ward parameter
    async function fetchAndDisplayFarmers(ward = null) {
        try {
            let url = 'php/get_all_farmers.php';
            if (ward) {
                // If a ward is provided, add it as a query parameter
                url += `?ward=${encodeURIComponent(ward)}`;
            }

            const response = await fetch(url);
            const data = await response.json();

            if (data.status === 'success' && data.farmers) {
                farmersTableBody.innerHTML = '';
                if (data.farmers.length > 0) {
                    data.farmers.forEach(farmer => {
                        addFarmerToTable(farmer);
                    });
                } else {
                    farmersTableBody.innerHTML = '<tr><td colspan="8">No farmers registered in this ward yet.</td></tr>';
                }
            } else {
                console.error('Failed to load farmers:', data.message || 'No farmers found.');
                farmersTableBody.innerHTML = '<tr><td colspan="8">Error loading farmers.</td></tr>';
            }
        } catch (error) {
            console.error('Error fetching farmers:', error);
            farmersTableBody.innerHTML = '<tr><td colspan="8">Error loading farmers.</td></tr>';
        }
    }

    // Function to fetch and display the officer ID and their assigned ward
    async function fetchOfficerProfileAndFarmers() {
        try {
            const officerProfileResponse = await fetch('php/get_officer_profile.php');
            const officerProfileData = await officerProfileResponse.json();

            if (officerProfileData.status === 'success' && officerProfileData.officer) {
                const officer = officerProfileData.officer;
                document.querySelector(".officer-id").textContent = officer.officer_id || 'N/A';
                officerAssignedWard = officer.ward; // Store the officer's ward

                // Now fetch farmers based on the assigned ward
                if (officerAssignedWard) {
                    fetchAndDisplayFarmers(officerAssignedWard);
                } else {
                    farmersTableBody.innerHTML = '<tr><td colspan="8">Officer has no assigned ward. Cannot display farmers.</td></tr>';
                }

            } else {
                console.error('Failed to fetch officer profile:', officerProfileData.message || 'Unknown error');
                document.querySelector(".officer-id").textContent = 'Officer ID: N/A';
                handleAuthError(officerProfileData); // Pass the data to the handler
            }
        } catch (error) {
            console.error('Error fetching officer profile:', error);
            document.querySelector(".officer-id").textContent = 'Officer ID: Error';
            farmersTableBody.innerHTML = '<tr><td colspan="8">Error fetching officer profile to filter farmers.</td></tr>';
        }
    }

    // Initial load: Fetch officer profile and then farmers
    fetchOfficerProfileAndFarmers();

    // Event delegation for delete buttons
    if (farmersTableBody) {
        farmersTableBody.addEventListener('click', function(event) {
            const target = event.target;
            if (target.classList.contains('delete-btn')) {
                farmerIdToDelete = target.dataset.farmerId;
                farmerNameToDelete = target.dataset.farmerName;

                if (farmerIdToDelete && farmerNameToDelete) {
                    confirmFarmerMessage.textContent = `Are you sure you want to delete farmer "${farmerNameToDelete}" (ID: ${farmerIdToDelete})? This action cannot be undone.`;
                    deleteFarmerConfirmPopup.style.display = 'flex'; // Show custom pop-up
                }
            }
        });
    }

    // Custom Delete Confirmation - Yes button
    if (confirmDeleteFarmerBtn) {
        confirmDeleteFarmerBtn.addEventListener('click', async () => {
            if (farmerIdToDelete) {
                try {
                    const response = await fetch('php/delete_farmer.php', { // PHP script to delete farmer
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `farmer_id=${farmerIdToDelete}`
                    });
                    const data = await response.json();

                    if (data.status === 'success') {
                        alert(data.message);
                        // Refresh list after deletion, passing the officer's ward
                        if (officerAssignedWard) {
                            fetchAndDisplayFarmers(officerAssignedWard);
                        } else {
                            fetchAndDisplayFarmers(); // Fallback
                        }
                    } else {
                        alert(data.message || 'Failed to delete farmer.');
                    }
                } catch (error) {
                    console.error('Error deleting farmer:', error);
                    alert('An error occurred during deletion. Please try again.');
                } finally {
                    deleteFarmerConfirmPopup.style.display = 'none'; // Hide pop-up
                    farmerIdToDelete = null; // Reset
                    farmerNameToDelete = null;
                }
            }
        });
    }

    // Custom Delete Confirmation - Cancel button
    if (cancelDeleteFarmerBtn) {
        cancelDeleteFarmerBtn.addEventListener('click', () => {
            deleteFarmerConfirmPopup.style.display = 'none'; // Hide pop-up
            farmerIdToDelete = null; // Reset
            farmerNameToDelete = null;
        });
    }

    // Sidebar active link management
    const navLinks = document.querySelectorAll('.sidebar a');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
        });
    });

    const activePath = window.location.pathname;
    navLinks.forEach(link => {
        // Correctly handle the active class for .php pages
        if (link.href.includes(activePath.replace('.html', '.php'))) {
            link.classList.add('active');
        }
    });
});