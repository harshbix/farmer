document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("toggleSidebar");
  const sidebar = document.getElementById("sidebar");
  const main = document.getElementById("main");
  const officerIdSpan = document.querySelector(".officer-id");

  const popup = document.getElementById("popupForm");
  const addBtn = document.getElementById("addOfficerBtn");
  const closePopup = document.getElementById("closePopup");
  const officerForm = document.getElementById("officerForm");
  const officerList = document.getElementById("officerList");
  const wardSelect = document.getElementById("wardInCharge");
  const wardLoading = document.getElementById("wardLoading");
  const submitBtn = document.getElementById("submitBtn");

  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("collapsed");
    main.classList.toggle("collapsed");
  });

  // Function to fetch and display the District Officer ID from the backend
  async function displayOfficerId() {
    try {
      const response = await fetch('php/get_district_profile.php');

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.status === 'success' && data.officer && data.officer.officer_id) {
        if (officerIdSpan) {
          officerIdSpan.textContent = data.officer.officer_id;
        }
      } else {
        if (officerIdSpan) {
          officerIdSpan.textContent = "N/A";
        }
        console.warn("Could not retrieve Officer ID:", data.message);
        if (data.redirect) {
          window.location.href = data.redirect;
        }
      }
    } catch (error) {
      console.error("Error fetching Officer ID:", error);
      if (officerIdSpan) {
        officerIdSpan.textContent = "Error";
      }
    }
  }

  // Function to fetch wards for the district
  async function fetchDistrictWards() {
    try {
      wardLoading.style.display = "block";
      wardSelect.disabled = true;
      
      const response = await fetch('php/get_district_wards.php');

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.status === 'success' && data.wards) {
        // Clear existing options except the first one
        wardSelect.innerHTML = '<option value="">Select Ward</option>';
        
        // Add wards to dropdown
        data.wards.forEach(ward => {
          const option = document.createElement('option');
          option.value = ward;
          option.textContent = ward;
          wardSelect.appendChild(option);
        });

        wardSelect.disabled = false;
      } else {
        console.error("Failed to fetch wards:", data.message);
        wardSelect.innerHTML = '<option value="">Error loading wards</option>';
        if (data.redirect) {
          window.location.href = data.redirect;
        }
      }
    } catch (error) {
      console.error("Error fetching wards:", error);
      wardSelect.innerHTML = '<option value="">Error loading wards</option>';
    } finally {
      wardLoading.style.display = "none";
    }
  }

  async function fetchExtensionOfficers() {
    try {
      const response = await fetch('php/get_all_extension_officers.php');

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      officerList.innerHTML = '';

      if (data.status === 'success' && data.officers && data.officers.length > 0) {
        data.officers.forEach(officer => {
          const row = document.createElement("tr");
          row.innerHTML = `
            <td>${officer.officer_id}</td>
            <td>${officer.full_name}</td>
            <td>${officer.email}</td>
            <td>${officer.ward}</td>
            <td>${officer.district || 'N/A'}</td>
            <td>
              <button class="delete" data-id="${officer.officer_id}">Delete</button>
            </td>
          `;
          officerList.appendChild(row);
        });

        // Add event listeners for new buttons
        attachOfficerEventListeners();

      } else if (data.status === 'success' && data.officers.length === 0) {
        officerList.innerHTML = `<tr><td colspan="6">No extension officers found.</td></tr>`;
      } else {
        officerList.innerHTML = `<tr><td colspan="6">Error: ${data.message || 'Failed to load officers.'}</td></tr>`;
        console.error("Server error:", data.message);
      }

    } catch (error) {
      console.error("Error fetching extension officers:", error);
      officerList.innerHTML = `<tr><td colspan="6">Error loading extension officers data. Please check your network connection or server.</td></tr>`;
    }
  }

  // Function to attach event listeners to dynamically created buttons
  function attachOfficerEventListeners() {
    officerList.querySelectorAll(".edit").forEach(button => {
      button.addEventListener("click", (e) => {
        const officerId = e.target.dataset.id;
        alert(`Edit functionality for officer ID: ${officerId} not yet implemented to backend.`);
        // TODO: Implement fetch call to php/update_extension_officer.php
      });
    });

    officerList.querySelectorAll(".delete").forEach(button => {
      button.addEventListener("click", async (e) => {
        const officerId = e.target.dataset.id;
        if (confirm(`Are you sure you want to delete officer with ID: ${officerId}?`)) {
          try {
            const response = await fetch('php/delete_extension_officer.php', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                officer_id: officerId
              })
            });

            const data = await response.json();

            if (data.status === 'success') {
              alert(data.message);
              fetchExtensionOfficers();
            } else {
              alert(data.message || 'Failed to delete officer.');
            }
          } catch (error) {
            console.error('Error deleting officer:', error);
            alert('An error occurred while deleting officer. Please try again.');
          }
        }
      });
    });
  }

  // "Add Officer" form submission
  officerForm.addEventListener("submit", async function (e) {
    e.preventDefault();

    const fullName = document.getElementById("fullName").value;
    const email = document.getElementById("emailAddress").value;
    const ward = document.getElementById("wardInCharge").value;
    const phone = document.getElementById("phoneNumber").value;

    // Validate form
    if (!fullName || !email || !ward || !phone) {
      alert('Please fill in all required fields.');
      return;
    }

    // Disable submit button to prevent double submission
    submitBtn.disabled = true;
    submitBtn.textContent = 'Registering...';

    // For now, let's send a dummy password to the backend for initial registration.
    const defaultPassword = "Password123"; 

    try {
      const response = await fetch('php/add_extension_officer.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          full_name: fullName,
          email: email,
          ward: ward,
          phone: phone,
          password: defaultPassword
        })
      });

      const data = await response.json();

      if (data.status === 'success') {
        alert(`Officer registered successfully!\nID: ${data.officer_id || 'N/A'}\nDistrict: ${data.district || 'N/A'}\nDefault password: "Password123"`);
        officerForm.reset();
        popup.style.display = "none";
        fetchExtensionOfficers();
      } else {
        alert(data.message || 'Failed to register officer.');
        if (data.redirect) {
          window.location.href = data.redirect;
        }
      }
    } catch (error) {
      console.error('Error registering officer:', error);
      alert('An error occurred while registering officer. Please try again.');
    } finally {
      // Re-enable submit button
      submitBtn.disabled = false;
      submitBtn.textContent = 'Register';
    }
  });

  // Popup form display controls
  addBtn.addEventListener("click", () => {
    officerForm.reset();
    popup.style.display = "flex";
    fetchDistrictWards(); // Load wards when popup opens
  });

  if (closePopup) {
    closePopup.addEventListener("click", () => {
      popup.style.display = "none";
    });
  }

  // Close popup when clicking outside
  window.addEventListener("click", (e) => {
    if (e.target === popup) {
      popup.style.display = "none";
    }
  });

  // Initialize page
  displayOfficerId();
  fetchExtensionOfficers();
});