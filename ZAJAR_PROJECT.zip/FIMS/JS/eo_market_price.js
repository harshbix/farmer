document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("toggleSidebar");
  const sidebar = document.getElementById("sidebar");
  const priceTableBody = document.getElementById("priceTableBody"); // Get the table body for prices
  const officerIdSpan = document.querySelector(".officer-id"); // Get the span element for officer ID

  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("collapsed");
  });

  // Function to fetch and display the officer ID
  async function fetchOfficerId() {
    try {
      // Assuming get_officer_profile.php is the correct path for Extension Officer profiles
      const officerProfileResponse = await fetch('php/get_officer_profile.php');
      const officerProfileData = await officerProfileResponse.json();

      if (officerProfileData.status === 'success' && officerProfileData.officer && officerProfileData.officer.officer_id) {
        if (officerIdSpan) {
          officerIdSpan.textContent = officerProfileData.officer.officer_id;
        }
      } else {
        console.error('Failed to fetch officer ID:', officerProfileData.message || 'Unknown error');
        if (officerIdSpan) {
          officerIdSpan.textContent = 'Officer ID: N/A';
        }
        // Assuming handleAuthError is defined elsewhere or this is just a console log
        // handleAuthError(officerProfileData);
      }
    } catch (error) {
      console.error('Error fetching officer profile:', error);
      if (officerIdSpan) {
        officerIdSpan.textContent = 'Officer ID: Error';
      }
    }
  }

  // Function to fetch and display market prices
  async function fetchMarketPrices() {
    try {
      // Assuming api/get_market_prices.php is the correct path for market prices
      const response = await fetch('php/get_market_prices.php');
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      const data = await response.json();

      if (data.status === 'success') {
        priceTableBody.innerHTML = ''; // Clear existing table content
        if (data.prices.length > 0) {
          data.prices.forEach((price, index) => { // Added index for '#' column
            const row = document.createElement("tr");
            row.innerHTML = `
              <td>${index + 1}</td> <td>${price.crop_name}</td>
              <td>${price.unit}</td>
              <td>${price.price_tsh}</td>
              <td>${price.market_name}</td>
              <td>${price.updated_at}</td>
            `;
            priceTableBody.appendChild(row);
          });
        } else {
          priceTableBody.innerHTML = '<tr><td colspan="5">No market prices recorded yet.</td></tr>'; //
        }
      } else {
        console.error("Server error fetching prices:", data.message);
        priceTableBody.innerHTML = `<tr><td colspan="5">Error loading prices: ${data.message}</td></tr>`; //
      }
    } catch (error) {
      console.error("Error fetching market prices:", error);
      priceTableBody.innerHTML = '<tr><td colspan="5">Failed to load market prices. Please try again.</td></tr>'; //
    }
  }

  // Call the functions when the DOM is fully loaded
  fetchOfficerId();
  fetchMarketPrices();
});