document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.getElementById("toggleSidebar");
    const sidebar = document.getElementById("sidebar");

    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("collapsed");
    });

    // Function to handle redirection on authentication failure from AJAX responses
    function handleAuthError(data) {
        // Check if the response contains a redirect URL
        if (data.status === 'error' && data.redirect) {
            window.location.href = data.redirect;
        }
    }

    // Function to fetch and display dashboard counts based on ward
    async function fetchDashboardCounts(ward) {
        try {
            // Fetch Farmer Count
            const farmerCountResponse = await fetch(`php/get_farmer_count.php?ward=${encodeURIComponent(ward)}`);
            const farmerCountData = await farmerCountResponse.json();
            if (farmerCountData.status === 'success') {
                document.getElementById("farmerCount").textContent = farmerCountData.count;
            } else {
                console.error('Failed to fetch farmer count:', farmerCountData.message);
                document.getElementById("farmerCount").textContent = '--';
                handleAuthError(farmerCountData); // Pass the data to the handler
            }

            // Fetch Farm Count (Total Verified Farms)
            const farmCountResponse = await fetch(`php/get_verified_farm_count.php?ward=${encodeURIComponent(ward)}`);
            const farmCountData = await farmCountResponse.json();
            if (farmCountData.status === 'success') {
                document.getElementById("farmCount").textContent = farmCountData.count;
            } else {
                console.error('Failed to fetch farm count:', farmCountData.message);
                document.getElementById("farmCount").textContent = '--';
                handleAuthError(farmCountData); // Pass the data to the handler
            }

            // Fetch Pending Farm Count
            const pendingFarmCountResponse = await fetch(`php/get_pending_farm_count.php?ward=${encodeURIComponent(ward)}`);
            const pendingFarmCountData = await pendingFarmCountResponse.json();
            if (pendingFarmCountData.status === 'success') {
                document.getElementById("pendingFarmCount").textContent = pendingFarmCountData.count;
            } else {
                console.error('Failed to fetch pending farm count:', pendingFarmCountData.message);
                document.getElementById("pendingFarmCount").textContent = '--';
                handleAuthError(pendingFarmCountData); // Pass the data to the handler
            }

        } catch (error) {
            console.error('Error fetching dashboard counts:', error);
        }
    }

    // Function to fetch and display the officer ID and their ward
    async function fetchOfficerProfileAndCounts() {
        let officerWard = null; // Declared here
        try {
            const officerProfileResponse = await fetch('php/get_officer_profile.php'); // Uses get_officer_profile.php
            const officerProfileData = await officerProfileResponse.json();

            if (officerProfileData.status === 'success' && officerProfileData.officer) {
                document.querySelector(".officer-id").textContent = officerProfileData.officer.officer_id;
                officerWard = officerProfileData.officer.ward; // Value assigned to officerWard
            } else {
                console.error('Failed to fetch officer profile:', officerProfileData.message || 'Unknown error');
                document.querySelector(".officer-id").textContent = 'Officer ID: N/A';
                handleAuthError(officerProfileData);
            }
        } catch (error) {
            console.error('Error fetching officer profile:', error);
            document.querySelector(".officer-id").textContent = 'Officer ID: Error';
        }

        // Now, fetch counts using the officerWard if available
        if (officerWard) {
            fetchDashboardCounts(officerWard); // officerWard is passed to fetchDashboardCounts
        } else {
            console.warn('Officer ward not available, cannot filter counts by ward.');
        }
    }

    // Call the new function to fetch officer profile and then dashboard counts when the page loads
    // Make sure to replace the old calls: fetchDashboardCounts(); and fetchOfficerId();
    fetchOfficerProfileAndCounts();

    // Event listener for sidebar links to add 'active' class
    const navLinks = document.querySelectorAll('.sidebar a');
    navLinks.forEach(link => {
        link.addEventListener('click', (event) => {
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
        });
    });

    // Set active link on page load
    const currentPath = window.location.pathname.split('/').pop();
    navLinks.forEach(link => {
        if (link.getAttribute('href').split('/').pop() === currentPath) {
            link.classList.add('active');
        }
    });
});