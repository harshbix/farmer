document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("toggleSidebar");
  const sidebar = document.getElementById("sidebar");
  const main = document.getElementById("main");
  const officerIdSpan = document.querySelector(".officer-id"); // Topbar officer ID

  // Profile display elements
  const profileName = document.querySelector(".profile-card p:nth-of-type(1) strong");
  const profileId = document.querySelector(".profile-card p:nth-of-type(2) strong");
  const profileEmail = document.querySelector(".profile-card p:nth-of-type(3) strong");
  const profileDistrict = document.querySelector(".profile-card p:nth-of-type(4) strong");

  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("collapsed");
    main.classList.toggle("collapsed");
  });

  // Function to fetch and display the District Officer Profile
  async function fetchOfficerProfile() {
    try {
      const response = await fetch('php/get_district_profile.php'); // Your PHP script to get the officer profile

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.status === 'success' && data.officer) {
        const officer = data.officer;

        // Update topbar officer ID
        if (officerIdSpan) {
          officerIdSpan.textContent = officer.officer_id;
        }

        // Update profile card details
        if (profileName) {
          profileName.textContent = 'Full Name: ' + officer.full_name;
        }
        if (profileId) {
          profileId.textContent = 'District Officer ID: ' + officer.officer_id;
        }
        if (profileEmail) {
          profileEmail.textContent = 'Email: ' +officer.email;
        }
        if (profileDistrict) {
          profileDistrict.textContent = 'District: ' + officer.district;
        }

      } else {
        console.error('Failed to fetch officer profile:', data.message || 'Unknown error');
        if (officerIdSpan) {
          officerIdSpan.textContent = 'DO ID: N/A';
        }
        // Redirect to login if unauthorized or session expired
        if (data.redirect) {
          window.location.href = data.redirect;
        }
      }
    } catch (error) {
      console.error('Error fetching officer profile:', error);
      if (officerIdSpan) {
        officerIdSpan.textContent = 'DO ID: Error';
      }
      alert('Error loading profile. Please try again.');
    }
  }

  // Password change form logic
  const form = document.getElementById("changePasswordForm");

  form.addEventListener("submit", async function (e) {
    e.preventDefault();

    const currentPassword = document.getElementById("currentPassword").value;
    const newPassword = document.getElementById("newPassword").value;
    const confirmPassword = document.getElementById("confirmPassword").value;

    if (newPassword !== confirmPassword) {
      alert("New passwords do not match.");
      return;
    }

    try {
      const response = await fetch('php/district_change_password.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          current_password: currentPassword,
          new_password: newPassword,
          confirm_password: confirmPassword
        })
      });

      const data = await response.json();

      if (data.status === 'success') {
        alert(data.message);
        form.reset(); // Clear the form on success
      } else {
        alert(data.message);
      }
    } catch (error) {
      console.error('Error changing password:', error);
      alert('An error occurred while changing password. Please try again.');
    }
  });

  // Call the function to fetch and display the profile when the page loads
  fetchOfficerProfile();
});