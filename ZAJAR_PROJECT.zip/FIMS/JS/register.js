document.addEventListener("DOMContentLoaded", function() {
    const registrationForm = document.getElementById("registrationForm");
    const districtSelect = document.getElementById("district");
    const wardSelect = document.getElementById("ward");
    const villageSelect = document.getElementById("village");
    const successPopup = document.getElementById("successPopup");
    const popupFarmerId = document.getElementById("popupFarmerId"); // Corrected ID as per register.html

    // Function to populate a dropdown
    function populateDropdown(selectElement, data, defaultOptionText) {
        selectElement.innerHTML = `<option value="">${defaultOptionText}</option>`;
        data.forEach(item => {
            const option = document.createElement("option");
            option.value = item.id; // Assuming the data has an 'id' field
            option.textContent = item.name; // Assuming the data has a 'name' field
            selectElement.appendChild(option);
        });
    }

    // Function to fetch districts from an API
    function fetchDistricts() {
        fetch('php/get_districts.php') // Your API endpoint to fetch districts
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                populateDropdown(districtSelect, data, "Select District");
                // Removed the automatic selection of Kahama here
            })
            .catch(error => {
                console.error("Error fetching districts:", error);
                alert("An error occurred while fetching districts.");
            });
    }

    // Function to fetch wards based on district ID
    function fetchWards(districtId) {
        if (!districtId) {
            wardSelect.innerHTML = '<option value="">Select Ward</option>';
            villageSelect.innerHTML = '<option value="">Select Village</option>';
            return;
        }
        fetch(`php/get_wards.php?district_id=${districtId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                populateDropdown(wardSelect, data, "Select Ward");
                villageSelect.innerHTML = '<option value="">Select Village</option>'; // Clear villages when ward changes
            })
            .catch(error => {
                console.error("Error fetching wards:", error);
                alert("An error occurred while fetching wards.");
            });
    }

    // Function to fetch villages based on ward ID
    function fetchVillages(wardId) {
        if (!wardId) {
            villageSelect.innerHTML = '<option value="">Select Village</option>';
            return;
        }
        fetch(`php/get_villages.php?ward_id=${wardId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok ' + response.statusText);
                }
                return response.json();
            })
            .then(data => {
                populateDropdown(villageSelect, data, "Select Village");
            })
            .catch(error => {
                console.error("Error fetching villages:", error);
                alert("An error occurred while fetching villages.");
            });
    }

    // Event listeners for dropdowns
    districtSelect.addEventListener("change", function() {
        fetchWards(this.value);
    });

    wardSelect.addEventListener("change", function() {
        fetchVillages(this.value);
    });

    // Initial load for districts
    fetchDistricts();

    // Form submission
    registrationForm.addEventListener("submit", function(e) {
        e.preventDefault();

        const formData = new FormData(this);

        // Append the selected text values for district, ward, and village
        // as the PHP script expects name strings, not just IDs.
        formData.append('district_name', districtSelect.options[districtSelect.selectedIndex].text);
        formData.append('ward_name', wardSelect.options[wardSelect.selectedIndex].text);
        formData.append('village_name', villageSelect.options[villageSelect.selectedIndex].text);

        fetch("php/register.php", {
            method: "POST",
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok ' + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === "success") {
                popupFarmerId.innerText = data.farmerId;
                successPopup.style.display = "block";

                // Redirect after 10 seconds
                setTimeout(() => {
                    window.location.href = "login.html";
                }, 10000);
            } else {
                alert("Registration failed: " + data.message);
            }
        })
        .catch(error => {
            console.error("Error:", error);
            alert("An error occurred. Please try again.");
        });
    });
});