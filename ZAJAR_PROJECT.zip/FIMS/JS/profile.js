document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.getElementById("toggleSidebar");
    const sidebar = document.getElementById("sidebar");
    const main = document.getElementById("main");

    // Get references to the new elements for profile display and editing
    const profileDisplayCard = document.querySelector(".profile-card"); // The display div
    const editProfileSection = document.getElementById("editProfileSection"); // The div containing the edit form
    const editProfileBtn = document.getElementById("editProfileBtn");
    const cancelEditBtn = document.getElementById("cancelEditBtn");

    // Get references to the profile input fields (from the original profileForm)
    const firstNameInput = document.getElementById("firstName");
    const middleNameInput = document.getElementById("middleName");
    const lastNameInput = document.getElementById("lastName");
    const phoneInput = document.getElementById("phone");
    const emailInput = document.getElementById("email");
    const villageInput = document.getElementById("village");
    const wardInput = document.getElementById("ward");
    const districtInput = document.getElementById("district");

    // Form references
    const profileForm = document.querySelector(".profile-form");
    const passwordForm = document.querySelector(".password-form");

    // Get references to password input fields
    const currentPasswordInput = document.getElementById("currentPassword");
    const newPasswordInput = document.getElementById("newPassword");
    const confirmPasswordInput = document.getElementById("confirmPassword");


    // Toggle sidebar visibility
    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("collapsed");
        main.classList.toggle("collapsed");
    });

    // Function to fetch and populate farmer data
    function fetchAndPopulateFarmerData() {
        fetch('php/get_farmer_data.php', {
            method: 'POST'
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success' && data.data) {
                const farmer = data.data;

                // Populate top bar Farmer ID
                const topBarFarmerIdElement = document.getElementById('displayTopBarFarmerId');
                if (topBarFarmerIdElement) {
                    topBarFarmerIdElement.innerText = farmer.farmer_id || '';
                }

                // Populate new Profile Display Card elements
                document.getElementById('displayProfileFarmerId').innerText = farmer.farmer_id || '';
                document.getElementById('displayProfileFullName').innerText = `${farmer.first_name || ''} ${farmer.middle_name || ''} ${farmer.last_name || ''}`.trim();
                document.getElementById('displayProfilePhone').innerText = farmer.phone || '';
                document.getElementById('displayProfileEmail').innerText = farmer.email || '';
                document.getElementById('displayProfileVillage').innerText = farmer.village || '';
                document.getElementById('displayProfileWard').innerText = farmer.ward || '';
                document.getElementById('displayProfileDistrict').innerText = farmer.district || '';

                // Populate Edit Form fields with current data
                firstNameInput.value = farmer.first_name || '';
                middleNameInput.value = farmer.middle_name || '';
                lastNameInput.value = farmer.last_name || '';
                phoneInput.value = farmer.phone || '';
                emailInput.value = farmer.email || '';
                villageInput.value = farmer.village || '';
                wardInput.value = farmer.ward || '';
                districtInput.value = farmer.district || '';

            } else {
                console.error('Server response error:', data.message || 'Unknown error from server.');
                window.location.href = 'login.html';
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
            alert('Could not load farmer data. Please try logging in again.');
            window.location.href = 'login.html';
        });
    }

    // Call the function to populate data on page load
    fetchAndPopulateFarmerData();

    // --- Profile Edit Section Logic ---
    // Show the edit profile form when "Edit Profile" button is clicked
    editProfileBtn.addEventListener("click", function() {
        profileDisplayCard.style.display = 'none'; // Hide the display card
        editProfileSection.style.display = 'block'; // Show the edit form section
    });

    // Hide the edit profile form when "Cancel" button is clicked
    cancelEditBtn.addEventListener("click", function() {
        editProfileSection.style.display = 'none'; // Hide the edit form section
        profileDisplayCard.style.display = 'block'; // Show the display card again
        // Re-populate display fields in case user cancelled after making changes to inputs
        fetchAndPopulateFarmerData(); // Re-fetch to ensure consistency if changes were made but not saved
    });

    // --- Profile Form Submission (to update database) ---
    profileForm.addEventListener("submit", function (e) {
        e.preventDefault(); // Prevent default form submission

        const formData = new FormData(profileForm); // Collect form data

        fetch('php/update_farmer_profile.php', { // Send data to the new PHP endpoint
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success' || data.status === 'info') {
                alert(data.message);
                // After successful update, re-fetch data to update display fields
                fetchAndPopulateFarmerData();
                editProfileSection.style.display = 'none'; // Hide the edit form
                profileDisplayCard.style.display = 'block'; // Show the display card
            } else {
                alert(data.message || 'Operation failed.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while saving your profile. Please try again.');
        });
    });

    // --- Password Form Submission (to update database) ---
    passwordForm.addEventListener("submit", function (e) {
        e.preventDefault(); // Prevent default form submission

        const newPassword = newPasswordInput.value;
        const confirmPassword = confirmPasswordInput.value;

        if (newPassword !== confirmPassword) {
            alert("New passwords do not match.");
            return; // Stop the function if passwords don't match
        }

        const formData = new FormData(passwordForm); // Collect form data including current, new, confirm passwords

        fetch('php/farmer_change_password.php', { // Send data to the new PHP endpoint
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success' || data.status === 'info') {
                alert(data.message);
                // Clear password fields on success
                currentPasswordInput.value = '';
                newPasswordInput.value = '';
                confirmPasswordInput.value = '';
            } else {
                alert(data.message || 'Password update failed.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while updating your password. Please try again.');
        });
    });
});