document.addEventListener("DOMContentLoaded", () => {
  const farmTableBody = document.getElementById("farmTableBody");
  const toggleBtn = document.getElementById("toggleSidebar");
  const sidebar = document.getElementById("sidebar");
  const main = document.getElementById("main");
  const officerIdSpan = document.querySelector(".officer-id");

  toggleBtn.addEventListener("click", function () {
    sidebar.classList.toggle("collapsed");
    main.classList.toggle("collapsed");
  });

  async function displayOfficerId() {
    try {
      const response = await fetch('php/get_district_profile.php');

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.status === 'success' && data.officer && data.officer.officer_id) {
        if (officerIdSpan) {
          officerIdSpan.textContent = data.officer.officer_id;
        }
      } else {
        if (officerIdSpan) {
          officerIdSpan.textContent = "N/A";
        }
        console.warn("Could not retrieve Officer ID:", data.message);
        if (data.redirect) {
          window.location.href = data.redirect;
        }
      }
    } catch (error) {
      console.error("Error fetching Officer ID:", error);
      if (officerIdSpan) {
        officerIdSpan.textContent = "Error";
      }
    }
  }

  async function fetchFarmsData() {
    try {
      const response = await fetch('php/district_farms.php'); //

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.status === 'success') {
        const farms = data.farms;
        farmTableBody.innerHTML = '';

        if (farms.length > 0) {
          farms.forEach(farm => {
            const row = document.createElement("tr");
            row.innerHTML = `
              <td>${farm.farm_id}</td>
              <td>${farm.farm_name}</td>
              <td>${farm.village}</td>
              <td>${farm.ward}</td>
              <td>${farm.crop_type}</td>
              <td>${farm.size_acres}</td>
              <td>${farm.status}</td>
            `;
            farmTableBody.appendChild(row);
          });
        } else {
          farmTableBody.innerHTML = `<tr><td colspan="7">No farms found.</td></tr>`; //
        }
      } else {
        // Handle error message from PHP script
        farmTableBody.innerHTML = `<tr><td colspan="7">Error: ${data.message}</td></tr>`; //
        console.error("Server error:", data.message); //
      }

    } catch (error) {
      console.error("Error fetching data:", error);
      farmTableBody.innerHTML = `<tr><td colspan="7">Error loading farms data. Please check your network connection and try again.</td></tr>`;
    }
  }

  // Call the function to fetch and display data when the page loads
  fetchFarmsData();
  displayOfficerId();
});