-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 05, 2025 at 10:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fims`
--

-- --------------------------------------------------------

--
-- Table structure for table `crops`
--

CREATE TABLE `crops` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `crops`
--

INSERT INTO `crops` (`id`, `name`) VALUES
(1, 'Maize'),
(2, 'Rice'),
(3, 'Sorghum'),
(4, 'Cassava'),
(5, 'Sweet potatoes'),
(6, 'Beans'),
(7, 'Bambara nuts'),
(8, 'Groundnuts'),
(9, 'Cotton'),
(10, 'Sunflower'),
(11, 'Cowpea'),
(12, 'Chickpea'),
(13, 'Cabbage'),
(14, 'Chinese cabbage'),
(15, 'Cucumber'),
(16, 'Onion'),
(17, 'Amaranths'),
(18, 'Pawpaw'),
(19, 'Okra'),
(20, 'Tomatoes'),
(21, 'Watermelon'),
(22, 'Sweet pepper'),
(23, 'Eggplant'),
(24, 'African Egg Plant'),
(25, 'Bell Pepper'),
(26, 'Chili Pepper'),
(27, 'Butternut'),
(28, 'Grams'),
(29, 'Carrots'),
(30, 'Beetroot'),
(31, 'Mangoes'),
(32, 'Passion'),
(33, 'Avocado'),
(34, 'Guava'),
(35, 'Pineapple'),
(36, 'Oranges'),
(37, 'Lemon'),
(38, 'Lime'),
(39, 'Kale'),
(40, 'Spinach'),
(41, 'Lettuce'),
(42, 'Cowpea Leaves'),
(43, 'Potato Leaves'),
(44, 'Pumpkin Leaves'),
(45, 'Leek'),
(46, 'Black Night Shade');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

CREATE TABLE `districts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `name`) VALUES
(1, 'Kahama');

-- --------------------------------------------------------

--
-- Table structure for table `district_officers`
--

CREATE TABLE `district_officers` (
  `id` int(11) NOT NULL,
  `officer_id` varchar(30) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `district` varchar(100) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `district_officers`
--

INSERT INTO `district_officers` (`id`, `officer_id`, `full_name`, `district`, `phone_number`, `email`, `password_hash`, `created_at`) VALUES
(1, 'DIS-2025-001', 'Athuman Sii Ntandu', 'Kahama', '0687692312', 'siintandu@gmail.com', '$2y$10$sNaMtzE2S4zzyTUa5EoU.O6As0lCXw8axG2D.3n28SevMn5oq9QHi', '2025-06-26 06:18:46');

-- --------------------------------------------------------

--
-- Table structure for table `extension_officers`
--

CREATE TABLE `extension_officers` (
  `id` int(11) NOT NULL,
  `officer_id` varchar(30) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `ward` varchar(100) DEFAULT NULL,
  `district` varchar(100) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `extension_officers`
--

INSERT INTO `extension_officers` (`id`, `officer_id`, `full_name`, `ward`, `district`, `phone_number`, `email`, `password_hash`, `created_at`) VALUES
(12, 'OFC-30424-555', 'Moses John Chumbi', 'Busoka', 'Kahama', '+255615414651', 'mozejohn5@gmail.com', '$2y$10$VQowikF.oa4XLg3MspMa8eEKQkyrT9bVtK83UjZmi8R9wkytvxG/C', '2025-07-06 19:33:45'),
(15, 'OFC-16174-757', 'Kelvin Alfred', 'Mhongolo', 'Kahama', '+255615414652', 'benjaminjoshua@gmail.com', '$2y$10$I8RDCBwkoe72n7Q56aIw9ONhE0WEmwuQ7qaF4oZGD9FcEiiZMqe6S', '2025-07-08 23:09:34');

-- --------------------------------------------------------

--
-- Table structure for table `farmers`
--

CREATE TABLE `farmers` (
  `id` int(11) NOT NULL,
  `farmer_id` varchar(30) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `village` varchar(100) NOT NULL,
  `ward` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `farmers`
--

INSERT INTO `farmers` (`id`, `farmer_id`, `first_name`, `middle_name`, `last_name`, `village`, `ward`, `district`, `phone`, `email`, `password_hash`, `created_at`) VALUES
(9, 'FMR-91403-319', 'Amina', 'Shabani', 'Msangi', 'Namanga', 'Kahama Mjini', 'Kahama', '+255787220696', 'aminashabani227@gmail.com', '$2y$10$hB7tlCAsjIEPjtP7.xgAbuB96ZA9mZNoO3azN0mrklhs2AR.4c8bm', '2025-07-06 08:43:23'),
(12, 'FMR-13176-675', 'Emmanuel', 'John', 'Majula', 'Sokola', 'Majengo', 'Kahama', '+255767800592', 'emajula@mantrac.co.tz', '$2y$10$GMSJQCIwGPYO8NnV.8Qdau6PoekaQW5AZeYkRQwA808T3qPWYkZ4a', '2025-07-06 14:46:16'),
(13, 'FMR-31464-316', 'Jamaly', 'Fadhili', 'Msangi', 'Kitwana', 'Busoka', 'Kahama', '+255658666427', 'jaymsangi912@gmail.com', '$2y$10$jLWZ5ZlwCNS1I/hTTH0M9.iGCN1zMqO8uHXq06wb03TYggh16XLx2', '2025-07-06 19:51:04'),
(14, 'FMR-09518-954', 'KELVIN', 'ALFRED', 'MHANGANYA', 'Mission', 'Mhongolo', 'Kahama', '0754205293', 'alfredkelvin587@gmail.com', '$2y$10$f0QdF78sEbN8dvdRopFKIe2uM0YCvvxRLD/akQvyGJSGbNmiY5VPK', '2025-07-20 11:05:18'),
(15, 'FMR-36334-178', 'EDGAR', 'THEONEST', 'NTAKILOWA', 'Kahanga', 'Wendele', 'Kahama', '0698321041', '', '$2y$10$hyfcSuOyH4FIXuRpudLLN.A8qSSVZechrrNk0c.zP5pO6u9KTlPTO', '2025-07-20 18:32:14');

-- --------------------------------------------------------

--
-- Table structure for table `farms`
--

CREATE TABLE `farms` (
  `farm_id` int(11) NOT NULL,
  `farmer_id` varchar(30) NOT NULL,
  `farm_name` varchar(100) NOT NULL,
  `village` varchar(100) DEFAULT NULL,
  `ward` varchar(25) NOT NULL,
  `district` varchar(25) NOT NULL,
  `size_acres` decimal(10,2) DEFAULT NULL,
  `crop_type` varchar(100) DEFAULT NULL,
  `status` enum('Pending','Verified','Rejected') DEFAULT 'Pending',
  `date_registered` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `farms`
--

INSERT INTO `farms` (`farm_id`, `farmer_id`, `farm_name`, `village`, `ward`, `district`, `size_acres`, `crop_type`, `status`, `date_registered`) VALUES
(26, 'FMR-91403-319', 'Karoti', 'Mission', 'Mhongolo', 'Kahama', 20.00, 'Carrots', 'Verified', '2025-07-06 09:06:38'),
(27, 'FMR-91403-319', 'Mahindi', 'Sokola', 'Majengo', 'Kahama', 50.00, 'Maize', 'Verified', '2025-07-06 14:09:12'),
(28, 'FMR-91403-319', 'Maharage', 'Busalala', 'Mwendakulima', 'Kahama', 30.00, 'Beans', 'Verified', '2025-07-06 14:22:21'),
(29, 'FMR-31464-316', 'Mpunga', 'Kitwana', 'Busoka', 'Kahama', 20.00, 'Rice', 'Verified', '2025-07-08 20:57:56'),
(30, 'FMR-91403-319', 'Karoti', 'Inyanga', 'Mhungula', 'Kahama', 2.00, 'Amaranths', 'Pending', '2025-07-09 08:20:08'),
(31, 'FMR-31464-316', 'cabbages', 'Sunge', 'Busoka', 'Kahama', 8.00, 'Cabbage', 'Pending', '2025-07-11 17:04:51');

-- --------------------------------------------------------

--
-- Table structure for table `market_prices`
--

CREATE TABLE `market_prices` (
  `id` int(11) NOT NULL,
  `crop_name` varchar(255) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `price_tsh` decimal(10,2) NOT NULL,
  `market_name` varchar(255) NOT NULL,
  `recorded_by_officer_id` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `market_prices`
--

INSERT INTO `market_prices` (`id`, `crop_name`, `unit`, `price_tsh`, `market_name`, `recorded_by_officer_id`, `created_at`, `updated_at`) VALUES
(1, 'Rice', 'kg', 1800.00, 'Mbeya', 'DIS-2025-001', '2025-06-27 08:39:19', '2025-06-27 08:39:19'),
(2, 'Beans', 'kg', 2300.00, 'Mwanza', 'DIS-2025-001', '2025-07-06 14:17:16', '2025-07-06 14:17:16');

-- --------------------------------------------------------

--
-- Table structure for table `outputs`
--

CREATE TABLE `outputs` (
  `output_id` int(11) NOT NULL,
  `farm_id` int(11) NOT NULL,
  `farmer_id` varchar(100) NOT NULL,
  `crop_name` varchar(100) DEFAULT NULL,
  `quantity` decimal(10,2) DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `outputs`
--

INSERT INTO `outputs` (`output_id`, `farm_id`, `farmer_id`, `crop_name`, `quantity`, `recorded_at`) VALUES
(11, 29, 'FMR-31464-316', 'Rice', 400.00, '2025-07-01 21:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `regions`
--

CREATE TABLE `regions` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `regions`
--

INSERT INTO `regions` (`id`, `name`) VALUES
(1, 'Arusha'),
(2, 'Dar es Salaam'),
(3, 'Dodoma'),
(4, 'Geita'),
(5, 'Iringa'),
(6, 'Kagera'),
(7, 'Katavi'),
(8, 'Kigoma'),
(9, 'Kilimanjaro'),
(10, 'Lindi'),
(11, 'Manyara'),
(12, 'Mara'),
(13, 'Mbeya'),
(14, 'Morogoro'),
(15, 'Mtwara'),
(16, 'Mwanza'),
(17, 'Njombe'),
(18, 'Pemba North'),
(19, 'Pemba South'),
(20, 'Pwani'),
(21, 'Rukwa'),
(22, 'Ruvuma'),
(23, 'Shinyanga'),
(24, 'Simiyu'),
(25, 'Singida'),
(31, 'Songwe'),
(26, 'Tabora'),
(27, 'Tanga'),
(28, 'Zanzibar Central/South'),
(29, 'Zanzibar North'),
(30, 'Zanzibar Urban/West');

-- --------------------------------------------------------

--
-- Table structure for table `villages`
--

CREATE TABLE `villages` (
  `id` int(11) NOT NULL,
  `ward_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `villages`
--

INSERT INTO `villages` (`id`, `ward_id`, `name`) VALUES
(1, 1, 'Sunge'),
(2, 1, 'Kitwana'),
(3, 1, 'Busoka'),
(4, 2, 'Mhongolo'),
(5, 2, 'Nyashimbi'),
(6, 2, 'Mission'),
(7, 2, 'Mbulu'),
(8, 3, 'Busalala'),
(9, 3, 'Mwendakulima Kati'),
(10, 3, 'Chapulwa'),
(11, 3, 'Mwime'),
(12, 4, 'Seeke'),
(13, 4, 'Zongomera'),
(14, 4, 'Ilindi'),
(15, 5, 'Mtakuja'),
(16, 5, 'Shunu'),
(17, 5, 'Nyahanga'),
(18, 6, 'Igomelo'),
(19, 6, 'Korogwe'),
(20, 6, 'Malunga'),
(21, 7, 'Sokola'),
(22, 7, 'Majengo'),
(23, 8, 'Sango'),
(24, 8, 'Nyakato'),
(25, 8, 'Nyasubi Kati'),
(26, 9, 'Nyihogo'),
(27, 9, 'Sazia'),
(28, 10, 'Bukondamoyo'),
(29, 10, 'Mhungula'),
(30, 10, 'Inyanga'),
(31, 11, 'Igalilimi'),
(32, 11, 'Namanga'),
(33, 12, 'Ilungu'),
(34, 12, 'Ishiki'),
(35, 12, 'Kawe'),
(36, 12, 'Iyenze'),
(37, 12, 'Isalenge'),
(38, 13, 'Wame'),
(39, 13, 'Ufala'),
(40, 13, 'Nyanhembe'),
(41, 13, 'Kilago'),
(42, 13, 'Tulole'),
(43, 13, 'Shininga'),
(44, 14, 'Kilengwe'),
(45, 14, 'Chalya'),
(46, 14, 'Lowa'),
(47, 14, 'Kakebe'),
(48, 14, 'Nyandekwa'),
(49, 14, 'Buduba'),
(50, 14, 'Bujika'),
(51, 15, 'Tumaini'),
(52, 15, 'Katungulu'),
(53, 15, 'Wendele'),
(54, 15, 'Kahanga'),
(55, 16, 'Ngulu'),
(56, 16, 'Nyambula'),
(57, 16, 'Ngogwa'),
(58, 16, 'Nuja'),
(59, 17, 'Ubilimbi'),
(60, 17, 'Igunghwa'),
(61, 17, 'Kinaga'),
(62, 17, 'Nduku'),
(63, 17, 'Magobeko'),
(64, 18, 'Penzi'),
(65, 18, 'Mwanzwagi'),
(66, 18, 'Mondo'),
(67, 18, 'Sangilwa'),
(68, 18, 'Bumbiti'),
(69, 19, 'Kagongwa'),
(70, 19, 'Gembe'),
(71, 19, 'Kishima'),
(72, 19, 'Iponya'),
(73, 20, 'Mpera'),
(74, 20, 'Kidunyashi'),
(75, 20, 'Isagehe'),
(76, 20, 'Malenge'),
(77, 20, 'Bukooba');

-- --------------------------------------------------------

--
-- Table structure for table `wards`
--

CREATE TABLE `wards` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `district_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wards`
--

INSERT INTO `wards` (`id`, `name`, `district_id`) VALUES
(1, 'Busoka', 1),
(2, 'Mhongolo', 1),
(3, 'Mwendakulima', 1),
(4, 'Zongomera', 1),
(5, 'Nyahanga', 1),
(6, 'Malunga', 1),
(7, 'Majengo', 1),
(8, 'Nyasubi', 1),
(9, 'Nyihogo', 1),
(10, 'Mhungula', 1),
(11, 'Kahama Mjini', 1),
(12, 'Iyenze', 1),
(13, 'Kilago', 1),
(14, 'Nyandekwa', 1),
(15, 'Wendele', 1),
(16, 'Ngogwa', 1),
(17, 'Kinaga', 1),
(18, 'Mondo', 1),
(19, 'Kagongwa', 1),
(20, 'Isagehe', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `district_officers`
--
ALTER TABLE `district_officers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `officer_id` (`officer_id`);

--
-- Indexes for table `extension_officers`
--
ALTER TABLE `extension_officers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `officer_id` (`officer_id`);

--
-- Indexes for table `farmers`
--
ALTER TABLE `farmers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `farmer_id` (`farmer_id`);

--
-- Indexes for table `farms`
--
ALTER TABLE `farms`
  ADD PRIMARY KEY (`farm_id`),
  ADD KEY `farmer_id` (`farmer_id`);

--
-- Indexes for table `market_prices`
--
ALTER TABLE `market_prices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `outputs`
--
ALTER TABLE `outputs`
  ADD PRIMARY KEY (`output_id`);

--
-- Indexes for table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `villages`
--
ALTER TABLE `villages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ward_id` (`ward_id`);

--
-- Indexes for table `wards`
--
ALTER TABLE `wards`
  ADD PRIMARY KEY (`id`),
  ADD KEY `district_id` (`district_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `district_officers`
--
ALTER TABLE `district_officers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `extension_officers`
--
ALTER TABLE `extension_officers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `farmers`
--
ALTER TABLE `farmers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `farms`
--
ALTER TABLE `farms`
  MODIFY `farm_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `market_prices`
--
ALTER TABLE `market_prices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `outputs`
--
ALTER TABLE `outputs`
  MODIFY `output_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `farms`
--
ALTER TABLE `farms`
  ADD CONSTRAINT `farms_ibfk_1` FOREIGN KEY (`farmer_id`) REFERENCES `farmers` (`farmer_id`) ON DELETE CASCADE;

--
-- Constraints for table `wards`
--
ALTER TABLE `wards`
  ADD CONSTRAINT `wards_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
